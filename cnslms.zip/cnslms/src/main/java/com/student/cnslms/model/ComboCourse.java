package com.student.cnslms.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class ComboCourse {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
        name = "combo_course_course",
        joinColumns = @JoinColumn(name = "combo_course_id"),
        inverseJoinColumns = @JoinColumn(name = "course_id")
    )
    private List<Course> courses;

    @ElementCollection
    @CollectionTable(name = "combo_course_requirements", joinColumns = @JoinColumn(name = "combo_course_id"))
    @Column(name = "requirement")
    private List<String> requirements;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }

    public List<String> getRequirements() {
        return requirements;
    }

    public void setRequirements(List<String> requirements) {
        this.requirements = requirements;
    }
}
