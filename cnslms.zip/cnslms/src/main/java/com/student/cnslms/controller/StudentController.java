package com.student.cnslms.controller;

import com.student.cnslms.model.Student;
import com.student.cnslms.model.Enrollment;
import com.student.cnslms.repository.StudentRepository;
import com.student.cnslms.repository.EnrollmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/students")
public class StudentController {
    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    @GetMapping
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    @PostMapping
    public Student createStudent(@RequestBody Student student) {
        return studentRepository.save(student);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Student> updateStudent(@PathVariable Long id, @RequestBody Student studentDetails) {
        Optional<Student> studentOptional = studentRepository.findById(id);

        if (!studentOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        Student student = studentOptional.get();
        student.setFirstName(studentDetails.getFirstName());
        student.setLastName(studentDetails.getLastName());
        student.setEmail(studentDetails.getEmail());
        student.setPhoneNumber(studentDetails.getPhoneNumber());
        student.setContactedStatus(studentDetails.getContactedStatus());
        student.setDescription(studentDetails.getDescription());

        Enrollment enrollment = student.getEnrollment();
        enrollment.setCourseType(studentDetails.getEnrollment().getCourseType());
        enrollment.setCourseName(studentDetails.getEnrollment().getCourseName());
        enrollment.setDays(studentDetails.getEnrollment().getDays());
        enrollment.setTraining(studentDetails.getEnrollment().isTraining());
        enrollment.setTrainingAndCertification(studentDetails.getEnrollment().isTrainingAndCertification());
        enrollment.setExam(studentDetails.getEnrollment().isExam());

        student.setEnrollment(enrollment);

        Student updatedStudent = studentRepository.save(student);
        return ResponseEntity.ok(updatedStudent);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStudent(@PathVariable Long id) {
        Optional<Student> studentOptional = studentRepository.findById(id);

        if (!studentOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        studentRepository.delete(studentOptional.get());
        return ResponseEntity.noContent().build();
    }
}
