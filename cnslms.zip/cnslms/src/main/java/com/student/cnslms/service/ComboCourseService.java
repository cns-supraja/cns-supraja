package com.student.cnslms.service;

import com.student.cnslms.model.ComboCourse;
import com.student.cnslms.repository.ComboCourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ComboCourseService {

    @Autowired
    private ComboCourseRepository comboCourseRepository;

    public List<ComboCourse> getAllComboCourses() {
        return comboCourseRepository.findAll();
    }

    public ComboCourse saveComboCourse(ComboCourse comboCourse) {
        return comboCourseRepository.save(comboCourse);
    }

    public Optional<ComboCourse> getComboCourseById(Long id) {
        return comboCourseRepository.findById(id);
    }

    public void deleteComboCourse(Long id) {
        comboCourseRepository.deleteById(id);
    }
}
