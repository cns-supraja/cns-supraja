package com.student.cnslms.service;

import com.student.cnslms.model.Student;
import com.student.cnslms.exception.ResourceNotFoundException;
import com.student.cnslms.model.Enrollment;
import com.student.cnslms.repository.StudentRepository;
import com.student.cnslms.repository.EnrollmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Student createStudent(Student student) {
        Enrollment enrollment = student.getEnrollment();
        if (enrollment != null) {
            enrollment = enrollmentRepository.save(enrollment);
            student.setEnrollment(enrollment);
        }
        return studentRepository.save(student);
    }

    public Student updateStudent(Long id, Student studentDetails) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found for this id :: " + id));

        student.setFirstName(studentDetails.getFirstName());
        student.setLastName(studentDetails.getLastName());
        student.setEmail(studentDetails.getEmail());
        student.setPhoneNumber(studentDetails.getPhoneNumber());
        student.setContactedStatus(studentDetails.getContactedStatus());
        student.setDescription(studentDetails.getDescription());

        Enrollment enrollment = studentDetails.getEnrollment();
        if (enrollment != null) {
            if (student.getEnrollment() != null) {
                enrollment.setId(student.getEnrollment().getId()); // Maintain existing enrollment ID
                enrollmentRepository.save(enrollment);
            } else {
                enrollment = enrollmentRepository.save(enrollment);
            }
            student.setEnrollment(enrollment);
        }

        return studentRepository.save(student);
    }

    public void deleteStudent(Long id) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found for this id :: " + id));

        studentRepository.delete(student);
    }
}
