package com.student.cnslms.controller;

import com.student.cnslms.model.ComboCourse;
import com.student.cnslms.service.ComboCourseService;
import com.student.cnslms.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/combo-course")
public class ComboCourseController {

    @Autowired
    private ComboCourseService comboCourseService;

    @Autowired
    private CourseService courseService; // Assuming you have a service for handling courses

    @GetMapping
    public List<ComboCourse> getAllComboCourses() {
        return comboCourseService.getAllComboCourses();
    }

    @PostMapping
    public ResponseEntity<?> addComboCourse(@RequestBody ComboCourse comboCourse) {
        try {
            // Check and save new courses if needed
            comboCourse.getCourses().forEach(course -> {
                if (course.getId() == null) {
                    courseService.saveCourse(course); // Assuming you have a method to save a course
                }
            });
            ComboCourse savedComboCourse = comboCourseService.saveComboCourse(comboCourse);
            return ResponseEntity.ok(savedComboCourse);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<ComboCourse> getComboCourseById(@PathVariable Long id) {
        return comboCourseService.getComboCourseById(id)
            .map(ResponseEntity::ok)
            .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteComboCourse(@PathVariable Long id) {
        comboCourseService.deleteComboCourse(id);
        return ResponseEntity.ok("Combo course deleted successfully");
    }
}
