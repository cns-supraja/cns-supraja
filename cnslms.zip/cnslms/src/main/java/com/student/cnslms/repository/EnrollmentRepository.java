// src/main/java/com/student/cnslms/repository/EnrollmentRepository.java
package com.student.cnslms.repository;

import com.student.cnslms.model.Enrollment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {
}

