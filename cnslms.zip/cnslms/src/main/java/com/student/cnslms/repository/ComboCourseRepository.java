package com.student.cnslms.repository;

import com.student.cnslms.model.ComboCourse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;



@Repository
public interface ComboCourseRepository extends JpaRepository<ComboCourse, Long> {
}