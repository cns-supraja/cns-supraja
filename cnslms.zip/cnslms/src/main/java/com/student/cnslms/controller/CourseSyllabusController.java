package com.student.cnslms.controller;

import com.student.cnslms.model.CourseSyllabus;
import com.student.cnslms.repository.CourseSyllabusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/course-syllabus")
public class CourseSyllabusController {

    @Autowired
    private CourseSyllabusRepository repository;

    @GetMapping
    public List<CourseSyllabus> getAllCourseSyllabuses() {
        return repository.findAll();
    }

    @PostMapping
    public CourseSyllabus addCourseSyllabus(@RequestBody CourseSyllabus syllabus) {
        return repository.save(syllabus);
    }
}