package com.student.cnslms.service;

import com.student.cnslms.model.CourseSyllabus;
import com.student.cnslms.repository.CourseSyllabusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseSyllabusService {

    @Autowired
    private CourseSyllabusRepository repository;

    public List<CourseSyllabus> getAllCourseSyllabuses() {
        return repository.findAll();
    }

    public CourseSyllabus addCourseSyllabus(CourseSyllabus syllabus) {
        return repository.save(syllabus);
    }

    public CourseSyllabus getCourseSyllabusById(Long id) {
        return repository.findById(id).orElse(null);
    }

    public void deleteCourseSyllabus(Long id) {
        repository.deleteById(id);
    }
}
