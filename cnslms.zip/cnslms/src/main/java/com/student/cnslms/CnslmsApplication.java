package com.student.cnslms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CnslmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CnslmsApplication.class, args);
	}

}
