// src/main/java/com/student/cnslms/controller/CourseController.java
package com.student.cnslms.controller;

import com.student.cnslms.model.Course;
import com.student.cnslms.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/course")
public class CourseController {

    @Autowired
    private CourseService courseService;

    @GetMapping
    public List<Course> getAllCourses() {
        return courseService.getAllCourses();
    }

    @PostMapping
    public ResponseEntity<String> addCourse(@RequestBody Course course) {
        if (course.getSyllabusId() == null || course.getType() == null) {
            return ResponseEntity.badRequest().body("Course syllabus and type must not be null");
        }
        courseService.saveCourse(course);
        return ResponseEntity.ok("Course added successfully");
    }

    @GetMapping("/{id}")
    public ResponseEntity<Course> getCourseById(@PathVariable Long id) {
        return courseService.getCourseById(id)
            .map(ResponseEntity::ok)
            .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCourse(@PathVariable Long id) {
        courseService.deleteCourse(id);
        return ResponseEntity.ok("Course deleted successfully");
    }
}
