// src/main/java/com/student/cnslms/service/CourseService.java
package com.student.cnslms.service;

import com.student.cnslms.model.Course;
import com.student.cnslms.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CourseService {

    @Autowired
    private CourseRepository repository;

    public List<Course> getAllCourses() {
        return repository.findAll();
    }

    public Course saveCourse(Course course) {
        return repository.save(course);
    }

    public Optional<Course> getCourseById(Long id) {
        return repository.findById(id);
    }

    public void deleteCourse(Long id) {
        repository.deleteById(id);
    }
    
}
