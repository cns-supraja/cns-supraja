package com.student.lmscns;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LmscnsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LmscnsApplication.class, args);
	}

}
