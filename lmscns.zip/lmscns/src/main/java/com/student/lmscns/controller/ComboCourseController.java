package com.student.lmscns.controller;

import com.student.lmscns.model.ComboCourse;
import com.student.lmscns.service.ComboCourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/combo-courses")
public class ComboCourseController {
    @Autowired
    private ComboCourseService comboCourseService;

    @PostMapping
    public ComboCourse createComboCourse(@RequestBody ComboCourse comboCourse) {
        return comboCourseService.saveComboCourse(comboCourse);
    }

    @GetMapping
    public List<ComboCourse> getAllComboCourses() {
        return comboCourseService.getAllComboCourses();
    }
}