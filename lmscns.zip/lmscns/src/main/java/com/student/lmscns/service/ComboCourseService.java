package com.student.lmscns.service;

import com.student.lmscns.model.ComboCourse;
import com.student.lmscns.repository.ComboCourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ComboCourseService {
    @Autowired
    private ComboCourseRepository comboCourseRepository;

    public ComboCourse saveComboCourse(ComboCourse comboCourse) {
        return comboCourseRepository.save(comboCourse);
    }

    public List<ComboCourse> getAllComboCourses() {
        return comboCourseRepository.findAll();
    }
}
