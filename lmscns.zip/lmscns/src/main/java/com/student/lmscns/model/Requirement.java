package com.student.lmscns.model;

public enum Requirement {
    TRAINING,
    TRAINING_AND_CERTIFICATION,
    EXAM
}
