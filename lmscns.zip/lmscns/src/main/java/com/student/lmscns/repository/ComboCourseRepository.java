package com.student.lmscns.repository;

import com.student.lmscns.model.ComboCourse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ComboCourseRepository extends JpaRepository<ComboCourse, Long> {
}
