package com.student.lmscns.model;

public enum CourseType {
    CNS,
    REDHAT,
    INTERNSHIP
}
