package com.student.lmscns.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class ComboCourse {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ElementCollection
    private List<String> courses;

    private boolean training;
    private boolean trainingAndCertification;
    private boolean exam;

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<String> getCourses() {
        return courses;
    }

    public void setCourses(List<String> courses) {
        this.courses = courses;
    }

    public boolean isTraining() {
        return training;
    }

    public void setTraining(boolean training) {
        this.training = training;
    }

    public boolean isTrainingAndCertification() {
        return trainingAndCertification;
    }

    public void setTrainingAndCertification(boolean trainingAndCertification) {
        this.trainingAndCertification = trainingAndCertification;
    }

    public boolean isExam() {
        return exam;
    }

    public void setExam(boolean exam) {
        this.exam = exam;
    }
}
