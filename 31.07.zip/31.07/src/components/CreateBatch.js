import React, { useState, useEffect } from 'react';
import axios from 'axios';

const CreateBatch = () => {
  const [courses, setCourses] = useState([]);
  const [studentOptions, setStudentOptions] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState('');
  const [scheduleDays, setScheduleDays] = useState('MON_WED_FRI');
  const [batchNumber, setBatchNumber] = useState('');
  const [date, setDate] = useState('');
  const [selectedStudents, setSelectedStudents] = useState([]);
  const [students, setStudents] = useState([]);

  useEffect(() => {
    // Fetch all courses
    axios.get('http://localhost:8080/api/batches/courses')
      .then(response => setCourses(response.data))
      .catch(error => console.error('Error fetching courses:', error));
  }, []);

  useEffect(() => {
    if (selectedCourse && date) {
      handleFetchStudents();
    }
  }, [selectedCourse, date]);

  const handleFetchStudents = () => {
    axios.get('http://localhost:8080/api/students/enrolled', {
      params: {
        courseId: selectedCourse,
        monthYear: date
      }
    })
    .then(response => setStudentOptions(response.data))
    .catch(error => console.error('Error fetching students:', error));
  };

  const handleAddStudent = () => {
    setStudents([...students, '']);
  };

  const handleRemoveStudent = index => {
    const newStudents = students.slice();
    newStudents.splice(index, 1);
    setStudents(newStudents);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const batchData = {
      courseId: selectedCourse,
      scheduleDays,
      batchNumber,
      date, // Pass the date directly
      studentIds: selectedStudents,
    };

    axios.post('http://localhost:8080/api/batches/create', batchData)
      .then(response => {
        console.log('Batch created:', response.data);
      })
      .catch(error => console.error('Error creating batch:', error));
  };

  return (
    <div>
      <h2>Create Batch</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Course:</label>
          <select value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)}>
            <option value="">Select a course</option>
            {courses.map(course => (
              <option key={course.id} value={course.id}>{course.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label>Schedule Days:</label>
          <select value={scheduleDays} onChange={(e) => setScheduleDays(e.target.value)}>
            <option value="MON_WED_FRI">MON_WED_FRI</option>
            <option value="TUE_THURS">TUE_THURS</option>
            <option value="SAT_SUN">SAT_SUN</option>
          </select>
        </div>
        <div>
          <label>Batch Number:</label>
          <input type="text" value={batchNumber} onChange={(e) => setBatchNumber(e.target.value)} />
        </div>
        <div>
          <label>Date:</label>
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </div>
        <div>
          <label>Students:</label>
          {students.map((student, index) => (
            <div key={index}>
              <select value={student} onChange={(e) => {
                const newStudents = students.slice();
                newStudents[index] = e.target.value;
                setStudents(newStudents);
              }}>
                <option value="">Select a student</option>
                {studentOptions.map(opt => (
                  <option key={opt.id} value={opt.id}>{opt.name}</option>
                ))}
              </select>
              <button type="button" onClick={() => handleRemoveStudent(index)}>X</button>
            </div>
          ))}
          <button type="button" onClick={handleAddStudent}>+</button>
        </div>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default CreateBatch;
