import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ViewBatches = () => {
  const [courses, setCourses] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState('');
  const [batches, setBatches] = useState([]);
  const [selectedBatch, setSelectedBatch] = useState(null);
  const [students, setStudents] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8080/api/batches/courses')
      .then(response => setCourses(response.data))
      .catch(error => console.error('Error fetching courses:', error));
  }, []);

  useEffect(() => {
    if (selectedCourse) {
      axios.get(`http://localhost:8080/api/batches/course/${selectedCourse}`)
        .then(response => setBatches(response.data))
        .catch(error => console.error('Error fetching batches:', error));
    }
  }, [selectedCourse]);

  const handleBatchSelect = (batchId) => {
    const batch = batches.find(b => b.id === batchId);
    setSelectedBatch(batch);
    setStudents(batch.students);
  };

  return (
    <div>
      <h2>View Batches</h2>
      <div>
        <label>Course:</label>
        <select value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)}>
          <option value="">Select a course</option>
          {courses.map(course => (
            <option key={course.id} value={course.id}>{course.name}</option>
          ))}
        </select>
      </div>
      <div>
        <label>Batch:</label>
        <select onChange={(e) => handleBatchSelect(e.target.value)}>
          <option value="">Select a batch</option>
          {batches.map(batch => (
            <option key={batch.id} value={batch.id}>{batch.batchNumber}</option>
          ))}
        </select>
      </div>
      {selectedBatch && (
        <div>
          <h3>Batch Details</h3>
          <p>Batch Number: {selectedBatch.batchNumber}</p>
          <p>Schedule Days: {selectedBatch.scheduleDays}</p>
          <p>Date: {selectedBatch.date}</p>
          <h4>Students</h4>
          <ul>
            {students.map(student => (
              <li key={student.id}>{student.name}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default ViewBatches;
