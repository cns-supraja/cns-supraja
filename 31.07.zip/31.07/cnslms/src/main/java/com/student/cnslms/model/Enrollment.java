package com.student.cnslms.model;

import jakarta.persistence.Embeddable;

@Embeddable
public class Enrollment {
    private String courseType;
    private String courseName;
    private String days;
    private boolean training;
    private boolean trainingAndCertification;
    private boolean exam;

    // Getters and Setters
    public String getCourseType() { return courseType; }
    public void setCourseType(String courseType) { this.courseType = courseType; }
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }
    public String getDays() { return days; }
    public void setDays(String days) { this.days = days; }
    public boolean isTraining() { return training; }
    public void setTraining(boolean training) { this.training = training; }
    public boolean isTrainingAndCertification() { return trainingAndCertification; }
    public void setTrainingAndCertification(boolean trainingAndCertification) { this.trainingAndCertification = trainingAndCertification; }
    public boolean isExam() { return exam; }
    public void setExam(boolean exam) { this.exam = exam; }
}