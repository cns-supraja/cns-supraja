package com.student.cnslms.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Entity
public class Batch {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "course_id")
    private Course course;

    @Enumerated(EnumType.STRING)
    private ScheduleDays scheduleDays;

    private String batchNumber;

    private LocalDate date; // Change to LocalDate

    @ManyToMany
    @JoinTable(
      name = "batch_student",
      joinColumns = @JoinColumn(name = "batch_id"),
      inverseJoinColumns = @JoinColumn(name = "student_id"))
    private List<Student> students;

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public ScheduleDays getScheduleDays() {
        return scheduleDays;
    }

    public void setScheduleDays(ScheduleDays scheduleDays) {
        this.scheduleDays = scheduleDays;
    }

    public String getBatchNumber() {
        return batchNumber;
    }

    public void setBatchNumber(String batchNumber) {
        this.batchNumber = batchNumber;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }
}
