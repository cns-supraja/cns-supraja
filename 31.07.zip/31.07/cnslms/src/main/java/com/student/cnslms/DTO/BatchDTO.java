package com.student.cnslms.DTO;

import com.student.cnslms.model.ScheduleDays;

import java.time.LocalDate;
import java.util.List;

public class BatchDTO {
    private Long courseId;
    private ScheduleDays scheduleDays;
    private String batchNumber;
    private LocalDate date; // Use LocalDate
    private List<Long> studentIds;

    // Getters and Setters

    public Long getCourseId() {
        return courseId;
    }

    public void setCourseId(Long courseId) {
        this.courseId = courseId;
    }

    public ScheduleDays getScheduleDays() {
        return scheduleDays;
    }

    public void setScheduleDays(ScheduleDays scheduleDays) {
        this.scheduleDays = scheduleDays;
    }

    public String getBatchNumber() {
        return batchNumber;
    }

    public void setBatchNumber(String batchNumber) {
        this.batchNumber = batchNumber;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public List<Long> getStudentIds() {
        return studentIds;
    }

    public void setStudentIds(List<Long> studentIds) {
        this.studentIds = studentIds;
    }
}
