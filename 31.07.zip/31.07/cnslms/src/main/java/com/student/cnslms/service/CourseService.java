// src/main/java/com/student/cnslms/service/CourseService.java
package com.student.cnslms.service;

import com.student.cnslms.model.Course;
import com.student.cnslms.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseService {
    @Autowired
    private CourseRepository courseRepository;

    public List<Course> getCoursesByType(String type) {
        return courseRepository.findByType(type);
    }
    
    public Course getCourseById(Long courseId) {
        return courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));
    }
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }
    
    public Course saveCourse(Course course) {
        return courseRepository.save(course);
    }
    
    public List<Course> getCoursesWithSyllabus() {
        return courseRepository.findAll(); // Adjust this if you need specific logic
    }
}