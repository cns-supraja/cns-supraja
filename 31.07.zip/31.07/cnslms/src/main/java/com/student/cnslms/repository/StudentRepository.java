package com.student.cnslms.repository;

import com.student.cnslms.model.Batch;
import com.student.cnslms.model.Student;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Long> {
	
	Student findByEmail(String email);
	 List<Student> findByBatch(Batch batch);
	 List<Student> findByBatchId(Long batchId);
	 List<Student> findStudentsByBatchId(Long batchId);
	 List<Student> findByCourseIdAndEnrollmentDateBetween(Long courseId, LocalDate startDate, LocalDate endDate);
}
