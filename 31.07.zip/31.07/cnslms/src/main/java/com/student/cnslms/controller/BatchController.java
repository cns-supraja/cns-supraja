package com.student.cnslms.controller;

import com.student.cnslms.DTO.BatchDTO;
import com.student.cnslms.model.Batch;
import com.student.cnslms.model.Course;
import com.student.cnslms.service.BatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/batches")
public class BatchController {

    @Autowired
    private BatchService batchService;

    @GetMapping("/courses")
    public List<Course> getAllCourses() {
        return batchService.getAllCourses();
    }

    @PostMapping("/create")
    public Batch createBatch(@RequestBody BatchDTO batchDTO) {
        return batchService.createBatch(
            batchDTO.getCourseId(),
            batchDTO.getScheduleDays(),
            batchDTO.getBatchNumber(),
            batchDTO.getDate(), // Pass LocalDate directly
            batchDTO.getStudentIds()
        );
    }

    @GetMapping("/course/{courseId}")
    public List<Batch> getBatchesByCourse(@PathVariable Long courseId) {
        return batchService.getBatchesByCourse(courseId);
    }

    @GetMapping("/course/{courseId}/date/{date}")
    public List<Batch> getBatchesByCourseAndDate(@PathVariable Long courseId, @PathVariable String date) {
        LocalDate dateParsed = LocalDate.parse(date); // Convert String to LocalDate
        return batchService.getBatchesByCourseAndDate(courseId, dateParsed);
    }

    @PostMapping("/addStudents")
    public Batch addStudentsToBatch(@RequestParam Long batchId, @RequestParam List<Long> studentIds) {
        return batchService.addStudentsToBatch(batchId, studentIds);
    }
}
