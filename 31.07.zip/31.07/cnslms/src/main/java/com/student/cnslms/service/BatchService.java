package com.student.cnslms.service;

import com.student.cnslms.model.Batch;
import com.student.cnslms.model.Course;
import com.student.cnslms.model.ScheduleDays;
import com.student.cnslms.model.Student;
import com.student.cnslms.repository.BatchRepository;
import com.student.cnslms.repository.CourseRepository;
import com.student.cnslms.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class BatchService {

    @Autowired
    private BatchRepository batchRepository;

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private StudentRepository studentRepository;

    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    public Batch createBatch(Long courseId, ScheduleDays scheduleDays, String batchNumber, LocalDate date, List<Long> studentIds) {
        Optional<Course> course = courseRepository.findById(courseId);
        if (!course.isPresent()) {
            throw new RuntimeException("Course not found");
        }

        List<Student> students = studentRepository.findAllById(studentIds);

        Batch batch = new Batch();
        batch.setCourse(course.get());
        batch.setScheduleDays(scheduleDays);
        batch.setBatchNumber(batchNumber);
        batch.setDate(date);
        batch.setStudents(students);

        return batchRepository.save(batch);
    }

    public List<Batch> getBatchesByCourse(Long courseId) {
        Optional<Course> course = courseRepository.findById(courseId);
        if (!course.isPresent()) {
            throw new RuntimeException("Course not found");
        }
        return batchRepository.findByCourse(course.get());
    }

    public List<Batch> getBatchesByCourseAndDate(Long courseId, LocalDate date) {
        Optional<Course> course = courseRepository.findById(courseId);
        if (!course.isPresent()) {
            throw new RuntimeException("Course not found");
        }
        return batchRepository.findByCourseAndDate(course.get(), date);
    }

    public Batch addStudentsToBatch(Long batchId, List<Long> studentIds) {
        Optional<Batch> batch = batchRepository.findById(batchId);
        if (!batch.isPresent()) {
            throw new RuntimeException("Batch not found");
        }

        List<Student> students = studentRepository.findAllById(studentIds);
        batch.get().getStudents().addAll(students);
        return batchRepository.save(batch.get());
    }
}
