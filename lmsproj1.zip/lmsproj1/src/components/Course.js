// src/components/Course.js
import React, { useState } from 'react';
import AddCourseSyllabus from './AddCourseSyllabus';
import AddCourse from './AddCourse';
import AddComboCourse from './AddComboCourse';

const Course = () => {
  const [form, setForm] = useState('syllabus');

  const handleFormChange = (formType) => {
    setForm(formType);
  };

  return (
    <div>
      <div className="form-navigation">
        <button onClick={() => handleFormChange('syllabus')}>Add Course Syllabus</button>
        <button onClick={() => handleFormChange('course')}>Add Course</button>
        <button onClick={() => handleFormChange('combo')}>Add Combo Course</button>
      </div>

      <div className="form-content">
        {form === 'syllabus' && <AddCourseSyllabus />}
        {form === 'course' && <AddCourse />}
        {form === 'combo' && <AddComboCourse />}
      </div>
    </div>
  );
};

export default Course;
