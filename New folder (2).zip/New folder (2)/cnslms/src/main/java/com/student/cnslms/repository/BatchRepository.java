package com.student.cnslms.repository;

import com.student.cnslms.model.Batch;
import com.student.cnslms.model.Student;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface BatchRepository extends JpaRepository<Batch, Long> {
    @Query("SELECT b FROM Batch b WHERE b.course.id = :courseId")
    List<Batch> findBatchesByCourseId(@Param("courseId") Long courseId);

    @Query("SELECT b.students FROM Batch b WHERE b.id = :batchId")
    List<Student> findStudentsByBatchId(@Param("batchId") Long batchId);
}