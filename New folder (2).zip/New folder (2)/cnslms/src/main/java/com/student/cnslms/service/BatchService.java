package com.student.cnslms.service;

import com.student.cnslms.model.Batch;
import com.student.cnslms.model.Student;
import com.student.cnslms.repository.BatchRepository;
import com.student.cnslms.repository.StudentRepository;

import jakarta.transaction.Transactional;

import com.student.cnslms.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class BatchService {

    @Autowired
    private BatchRepository batchRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private CourseRepository courseRepository;

    public Batch createBatch(Batch batch) {
        List<Student> students = batch.getStudents();
        List<Student> persistedStudents = new ArrayList<>();
        for (Student student : students) {
            Student persistedStudent = studentRepository.findById(student.getId())
                .orElseThrow(() -> new IllegalArgumentException("Student not found"));
            persistedStudents.add(persistedStudent);
        }
        batch.setStudents(persistedStudents);
        return batchRepository.save(batch);
    }

    public List<Student> getStudentsByCourseAndDateRange(Long courseId, LocalDate startDate, LocalDate endDate) {
        return studentRepository.findStudentsByCourseAndDateRange(courseId, startDate, endDate);
    }

    public List<Batch> getBatchesByCourse(Long courseId) {
        return batchRepository.findBatchesByCourseId(courseId);
    }

    public Optional<Batch> getBatchById(Long id) {
        return batchRepository.findById(id);
    }
    
    public List<Student> findStudentsByBatchId(Long batchId) {
        // Assuming you have a method in your repository to fetch students by batch ID
        return batchRepository.findStudentsByBatchId(batchId);
    }
    
    public Batch saveBatch(Batch batch) {
        System.out.println("Saving batch with students: " + batch.getStudents());
        return batchRepository.save(batch);
    }
    
}
