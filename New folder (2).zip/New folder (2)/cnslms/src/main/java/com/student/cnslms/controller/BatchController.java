package com.student.cnslms.controller;

import com.student.cnslms.model.Batch;
import com.student.cnslms.model.Course;
import com.student.cnslms.model.Student;
import com.student.cnslms.service.BatchService;
import com.student.cnslms.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/batches")
public class BatchController {

    @Autowired
    private BatchService batchService;

    @Autowired
    private CourseRepository courseRepository; // Add repository dependency

    
    @PostMapping("/create")
    public ResponseEntity<Batch> createBatch(@RequestBody Batch batch) {
        if (batch.getCourse() == null || batch.getCourse().getId() == null) {
            return ResponseEntity.badRequest().body(null);
        }
        Course course = courseRepository.findById(batch.getCourse().getId())
            .orElseThrow(() -> new IllegalArgumentException("Course not found"));
        batch.setCourse(course);
        
        // Save the batch
        Batch createdBatch = batchService.createBatch(batch);
        
        return ResponseEntity.ok(createdBatch);
    }
    @GetMapping("/students")
    public List<Student> getStudentsByCourseAndDateRange(
            @RequestParam Long courseId,
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate) {
        return batchService.getStudentsByCourseAndDateRange(courseId, startDate, endDate);
    }

    @GetMapping
    public List<Batch> getBatchesByCourse(@RequestParam Long courseId) {
        return batchService.getBatchesByCourse(courseId);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Batch> getBatchById(@PathVariable Long id) {
        Optional<Batch> batch = batchService.getBatchById(id);
        return batch.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/{batchId}/students")
    public ResponseEntity<List<Student>> getStudentsByBatchId(@PathVariable Long batchId) {
        List<Student> students = batchService.findStudentsByBatchId(batchId);
        return ResponseEntity.ok(students);
    }
}
