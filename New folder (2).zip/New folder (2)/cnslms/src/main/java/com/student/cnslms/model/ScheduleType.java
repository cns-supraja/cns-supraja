package com.student.cnslms.model;

public enum ScheduleType {
	 WEEKDAY,
	    WEEKEND
}
