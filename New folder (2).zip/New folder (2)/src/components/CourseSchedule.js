import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useForm, Controller } from 'react-hook-form';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
//import './CourseSchedule.css';

const CourseSchedule = () => {
  const [courses, setCourses] = useState([]);
  const [trainers, setTrainers] = useState([]);
  const [schedules, setSchedules] = useState([]);
  const [currentSchedule, setCurrentSchedule] = useState(null);
  const { register, handleSubmit, reset, setValue, watch, control } = useForm({
    defaultValues: {
      course: '',
      trainer: '',
      scheduleType: 'WEEKDAY',
      mode: 'ONLINE',
      scheduleDays: 'MON_WED_FRI',
      startDate: new Date(),
      endDate: new Date(),
      time: '',
    },
  });

  const startDate = watch('startDate');
  const endDate = watch('endDate');

  useEffect(() => {
    fetchCourses();
    fetchTrainers();
    fetchSchedules();
  }, []);

  useEffect(() => {
    if (currentSchedule) {
      reset({
        ...currentSchedule,
        course: currentSchedule.course?.id,
        trainer: currentSchedule.trainer?.id,
        startDate: new Date(currentSchedule.startDate),
        endDate: new Date(currentSchedule.endDate),
      });
    } else {
      reset({
        course: '',
        trainer: '',
        scheduleType: 'WEEKDAY',
        mode: 'ONLINE',
        scheduleDays: 'MON_WED_FRI',
        startDate: new Date(),
        endDate: new Date(),
        time: '',
      });
    }
  }, [currentSchedule, reset]);

  useEffect(() => {
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      const months = (end.getFullYear() - start.getFullYear()) * 12 + (end.getMonth() - start.getMonth());
      setValue('duration', `${months} months`);
    }
  }, [startDate, endDate, setValue]);

  const fetchCourses = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/courses');
      console.log('Fetched courses:', response.data); // Log fetched data
      if (Array.isArray(response.data)) {
        setCourses(response.data);
      } else {
        console.error('Courses data is not an array:', response.data);
        setCourses([]);
      }
    } catch (error) {
      console.error('Error fetching courses', error);
      setCourses([]);
    }
  };

  const fetchTrainers = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/trainers');
      console.log('Fetched trainers:', response.data); // Log fetched data
      setTrainers(Array.isArray(response.data) ? response.data : []);
    } catch (error) {
      console.error('Error fetching trainers:', error);
      setTrainers([]);
    }
  };

  const fetchSchedules = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/course-schedules');
      console.log('Fetched schedules:', response.data); // Log fetched data
      setSchedules(Array.isArray(response.data) ? response.data : []);
    } catch (error) {
      console.error('Error fetching schedules:', error);
      setSchedules([]);
    }
  };

  const handleFormSubmit = async (data) => {
    try {
      const selectedCourse = courses.find(course => course.id === parseInt(data.course));
      const selectedTrainer = trainers.find(trainer => trainer.id === parseInt(data.trainer));

      const cleanedData = {
        ...data,
        courseName: selectedCourse ? selectedCourse.name : '',
        trainerName: selectedTrainer ? selectedTrainer.firstName : '',
        startDate: data.startDate.toISOString().split('T')[0],
        endDate: data.endDate.toISOString().split('T')[0],
      };

      if (currentSchedule) {
        await axios.put(`http://localhost:8080/api/course-schedules/${currentSchedule.id}`, cleanedData);
      } else {
        await axios.post('http://localhost:8080/api/course-schedules', cleanedData);
      }

      fetchSchedules();
      setCurrentSchedule(null);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleEdit = (schedule) => {
    setCurrentSchedule(schedule);
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:8080/api/course-schedules/${id}`);
      fetchSchedules();
    } catch (error) {
      console.error('Error deleting schedule:', error);
    }
  };

  return (
    <div className="container">
      <h1>Course Schedule</h1>
      <form onSubmit={handleSubmit(handleFormSubmit)}>
        <div className="form-row">
          <label>Course:</label>
          <select {...register('course')} required>
            <option value="" disabled>Select a course</option>
            {Array.isArray(courses) && courses.map((course) => (
              <option key={course.id} value={course.id}>
                {course.name}
              </option>
            ))}
          </select>
        </div>
        
        <div className="form-row">
          <label>Trainer:</label>
          <select {...register('trainer')} required>
            <option value="" disabled>Select a trainer</option>
            {Array.isArray(trainers) && trainers.map((trainer) => (
              <option key={trainer.id} value={trainer.id}>
                {trainer.firstName}
              </option>
            ))}
          </select>
        </div>
        
        <div className="form-row">
          <label>Schedule Type:</label>
          <select {...register('scheduleType')} required>
            <option value="WEEKDAY">WEEKDAY</option>
            <option value="WEEKEND">WEEKEND</option>
          </select>
        </div>
        
        <div className="form-row">
          <label>Mode:</label>
          <select {...register('mode')} required>
            <option value="ONLINE">ONLINE</option>
            <option value="OFFLINE">OFFLINE</option>
          </select>
        </div>
        
        <div className="form-row">
          <label>Schedule Days:</label>
          <select {...register('scheduleDays')} required>
            <option value="MON_WED_FRI">MON_WED_FRI</option>
            <option value="TUE_THURS">TUE_THURS</option>
            <option value="SAT_SUN">SAT_SUN</option>
          </select>
        </div>
        
        <div className="form-row">
          <label>Start Date:</label>
          <Controller
            control={control}
            name="startDate"
            render={({ field }) => <DatePicker selected={field.value} onChange={field.onChange} />}
          />
        </div>
        
        <div className="form-row">
          <label>End Date:</label>
          <Controller
            control={control}
            name="endDate"
            render={({ field }) => <DatePicker selected={field.value} onChange={field.onChange} />}
          />
        </div>
        
        <div className="form-row">
          <label>Time:</label>
          <input type="text" {...register('time')} required />
        </div>
        
        <div className="form-row">
          <label>Duration:</label>
          <input type="text" {...register('duration')} readOnly />
        </div>
        
        <div className="form-row">
          <button type="submit">Save Schedule</button>
          <button type="button" onClick={() => setCurrentSchedule(null)}>Cancel</button>
        </div>
      </form>
      
      <h2>Existing Schedules</h2>
      <table className="schedule-table">
        <thead>
          <tr>
            <th>Course</th>
            <th>Trainer</th>
            <th>Type</th>
            <th>Mode</th>
            <th>Days</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Time</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {schedules.map((schedule) => (
            <tr key={schedule.id}>
              <td>{schedule.courseName}</td>
              <td>{schedule.trainerName}</td>
              <td>{schedule.scheduleType}</td>
              <td>{schedule.mode}</td>
              <td>{schedule.scheduleDays}</td>
              <td>{new Date(schedule.startDate).toLocaleDateString()}</td>
              <td>{new Date(schedule.endDate).toLocaleDateString()}</td>
              <td>{schedule.time}</td>
              <td>
                <button onClick={() => handleEdit(schedule)}>Edit</button>
                <button onClick={() => handleDelete(schedule.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CourseSchedule;
