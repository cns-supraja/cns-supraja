import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './AddCourse.css';

function AddCourse() {
  const [syllabuses, setSyllabuses] = useState([]);
  const [selectedSyllabus, setSelectedSyllabus] = useState('');
  const [courseType, setCourseType] = useState('CNS');
  const [requirements, setRequirements] = useState({
    training: false,
    certification: false,
    exam: false
  });

  useEffect(() => {
    axios.get('http://localhost:8080/api/course-syllabus')
      .then(response => setSyllabuses(response.data))
      .catch(error => console.error(error));
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    const data = {
      syllabusId: selectedSyllabus,
      type: courseType,
      requirements: Object.keys(requirements).filter(key => requirements[key])
    };

    axios.post('http://localhost:8080/api/course', data)
      .then(response => {
        console.log(response.data);
        setSelectedSyllabus('');
        setCourseType('CNS');
        setRequirements({ training: false, certification: false, exam: false });
      })
      .catch(error => {
        console.error('Error:', error);
        if (error.response) {
          console.error('Server Response:', error.response.data);
        }
      });
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Course Syllabus:</label>
        <select 
          value={selectedSyllabus} 
          onChange={(e) => setSelectedSyllabus(e.target.value)} 
          required
        >
          <option value="">Select a syllabus</option>
          {syllabuses.map(syllabus => (
            <option key={syllabus.id} value={syllabus.id}>
              {syllabus.courseName}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label>Type:</label>
        <select 
          value={courseType} 
          onChange={(e) => setCourseType(e.target.value)} 
          required
        >
          <option value="CNS">CNS courses</option>
          <option value="Redhat">Redhat Course</option>
          <option value="Internship">Internship</option>
        </select>
      </div>
      <div>
        <label>Requirements:</label>
        <div>
          <label>
            <input 
              type="checkbox" 
              checked={requirements.training} 
              onChange={() => setRequirements({...requirements, training: !requirements.training})} 
            /> Training
          </label>
          <label>
            <input 
              type="checkbox" 
              checked={requirements.certification} 
              onChange={() => setRequirements({...requirements, certification: !requirements.certification})} 
            /> Training and Certification
          </label>
          <label>
            <input 
              type="checkbox" 
              checked={requirements.exam} 
              onChange={() => setRequirements({...requirements, exam: !requirements.exam})} 
            /> Exam
          </label>
        </div>
      </div>
      <button type="submit">Submit</button>
    </form>
  );
}

export default AddCourse;
