import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ViewBatches = () => {
  const [courses, setCourses] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState('');
  const [batches, setBatches] = useState([]);
  const [selectedBatch, setSelectedBatch] = useState('');
  const [students, setStudents] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  // Fetch courses on component mount
  useEffect(() => {
    setLoading(true);
    axios.get('http://localhost:8080/api/courses')
      .then(response => {
        setCourses(response.data);
      })
      .catch(error => {
        setError('Error fetching courses');
        console.error('Error fetching courses:', error);
      })
      .finally(() => setLoading(false));
  }, []);

  // Fetch batches when a course is selected
  useEffect(() => {
    if (selectedCourse) {
      setLoading(true);
      axios.get(`http://localhost:8080/api/batches?courseId=${selectedCourse}`)
        .then(response => {
          setBatches(response.data);
        })
        .catch(error => {
          setError('Error fetching batches');
          console.error('Error fetching batches:', error);
          setBatches([]);
        })
        .finally(() => setLoading(false));
    } else {
      setBatches([]);
    }
  }, [selectedCourse]);

  // Fetch students when a batch is selected
  useEffect(() => {
    if (selectedBatch) {
      setLoading(true);
      axios.get(`http://localhost:8080/api/batches/${selectedBatch}/students`)
        .then(response => {
          setStudents(response.data);
        })
        .catch(error => {
          setError('Error fetching students');
          console.error('Error fetching students:', error);
          setStudents([]);
        })
        .finally(() => setLoading(false));
    } else {
      setStudents([]);
    }
  }, [selectedBatch]);

  // Handle batch selection
  const handleBatchSelect = (event) => {
    const batchId = event.target.value;
    setSelectedBatch(batchId);
  };

  return (
    <div>
      <h2>View Batches</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {loading && <p>Loading...</p>}
      <div>
        <label>Course:</label>
        <select value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)} disabled={loading}>
          <option value="">Select a course</option>
          {courses.map(course => (
            <option key={course.id} value={course.id}>{course.name}</option>
          ))}
        </select>
      </div>
      <div>
        <label>Batch:</label>
        <select value={selectedBatch} onChange={handleBatchSelect} disabled={loading}>
          <option value="">Select a batch</option>
          {batches.map(batch => (
            <option key={batch.id} value={batch.id}>{batch.batchNumber}</option>
          ))}
        </select>
      </div>
      {selectedBatch && (
        <div>
          <h3>Batch Details</h3>
          
          <h4>Students</h4>
          <ul>
            {students.length > 0 ? (
              students.map(student => (
                <li key={student.id}>{student.firstName} {student.lastName}</li>
              ))
            ) : (
              <p>No students enrolled</p>
            )}
          </ul>
        </div>
      )}
    </div>
  );
};

export default ViewBatches;
