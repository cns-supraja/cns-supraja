import React, { useState } from 'react';

import TrainerCourseSchedule from './TrainerCourseSchedule';

import Logout from './Logout';

import './TrainerCourseSchedule.css';


const HomePage = () => {
  const [view, setView] = useState('home');

  return (
    <div className="home-page">
      <div className="navbar">
        
        <ul>
         
          <li onClick={() => setView('TrainerCourseSchedule')}>Course Schedule</li>
          <li onClick={() => setView('logout')}>Logout</li>
        
        </ul>
      </div>
      <div className="content">
        {view === 'home' && <div>Welcome to the LMS Home Page</div>}
        
        
        {view === 'TrainerCourseSchedule' && <TrainerCourseSchedule />}
        {view === 'Logout' && <Logout />}
       
        
      </div>
    </div>
  );
};

export default HomePage;

