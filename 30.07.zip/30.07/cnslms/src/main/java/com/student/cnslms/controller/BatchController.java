package com.student.cnslms.controller;

import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.student.cnslms.service.BatchService;
import com.student.cnslms.model.Course;
import com.student.cnslms.model.ScheduleDays;
import com.student.cnslms.service.CourseService;
import com.student.cnslms.service.StudentService;
import com.student.cnslms.model.Batch;
import com.student.cnslms.model.Student;

@RestController
@RequestMapping("/api/batches")
public class BatchController {
    @Autowired
    private BatchService batchService;

    @PostMapping
    public ResponseEntity<Batch> createBatch(@RequestBody Batch batch) {
        return new ResponseEntity<>(batchService.saveBatch(batch), HttpStatus.CREATED);
    }

    @GetMapping
    public List<Batch> getAllBatches() {
        return batchService.getAllBatches();
    }
    
    @GetMapping("/{batchId}/students")
    public ResponseEntity<List<Student>> getStudentsByBatchId(@PathVariable Long batchId) {
        List<Student> students = batchService.getStudentsByBatchId(batchId);
        return ResponseEntity.ok(students);
    }
}