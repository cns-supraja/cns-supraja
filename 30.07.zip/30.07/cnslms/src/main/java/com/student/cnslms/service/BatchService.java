package com.student.cnslms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.cnslms.repository.BatchRepository;
import com.student.cnslms.repository.StudentRepository;

import jakarta.transaction.Transactional;

import com.student.cnslms.exception.ResourceNotFoundException;
import com.student.cnslms.model.Batch;
import com.student.cnslms.model.Student;

@Service
public class BatchService {

    @Autowired
    private BatchRepository batchRepository;
    
    @Autowired
    private StudentRepository studentRepository;
    
    @Transactional
    public Batch saveBatch(Batch batch) {
        List<Student> students = new ArrayList<>();
        for (Student student : batch.getStudents()) {
            // Check if the student is already in the database
            if (student.getId() == null) {
                student = studentRepository.save(student);
            }
            students.add(student);
        }
        batch.setStudents(students);
        return batchRepository.save(batch);
    }

    public List<Student> getStudentsByBatchId(Long batchId) {
        // Fetch the batch by ID
        Batch batch = batchRepository.findById(batchId)
            .orElseThrow(() -> new ResourceNotFoundException("Batch not found with id " + batchId));

        // Return the list of students for the batch
        return studentRepository.findByBatch(batch);
    }
 
    public List<Batch> getAllBatches() {
        return batchRepository.findAll();
    }

    public Optional<Batch> getBatchById(Long id) {
        return batchRepository.findById(id);
    }

    public void deleteBatch(Long id) {
        batchRepository.deleteById(id);
    }
}
