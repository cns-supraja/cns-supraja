package com.student.cnslms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.student.cnslms.model.Course;
import com.student.cnslms.model.Batch;

public interface BatchRepository extends JpaRepository<Batch, Long> {
	List<Batch> findByCourse(Course course);
    List<Batch> findByCourseId(Long courseId);
}
