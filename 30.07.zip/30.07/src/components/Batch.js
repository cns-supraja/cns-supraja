import React, { useState, useEffect } from 'react';
import axios from 'axios';
//import './Batch.css';

const Batch = () => {
  const [courses, setCourses] = useState([]);
  const [students, setStudents] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState('');
  const [batches, setBatches] = useState([]);
  const [selectedBatch, setSelectedBatch] = useState('');
  const [scheduleDay, setScheduleDay] = useState('');
  const [batchNumber, setBatchNumber] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedStudents, setSelectedStudents] = useState([{ studentId: '' }]);

  useEffect(() => {
    fetchCourses();
  }, []);

  const fetchCourses = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/courses');
      setCourses(response.data);
    } catch (error) {
      console.error('Error fetching courses:', error);
    }
  };

  const fetchStudents = async (courseName, startDate) => {
    try {
      const response = await axios.get(`http://localhost:8080/api/students?courseName=${courseName}&startDate=${startDate}`);
      setStudents(response.data);
    } catch (error) {
      console.error('Error fetching students:', error);
    }
  };

  const fetchBatches = async (courseName) => {
    try {
      const response = await axios.get(`http://localhost:8080/api/batches?courseName=${courseName}`);
      setBatches(response.data);
    } catch (error) {
      console.error('Error fetching batches:', error);
    }
  };

  const fetchStudentsForBatch = async (batchId) => {
    try {
      const response = await axios.get(`http://localhost:8080/api/batches/${batchId}/students`);
      setStudents(response.data);
    } catch (error) {
      console.error('Error fetching students for batch:', error);
    }
  };

  const handleCourseChange = (e) => {
    setSelectedCourse(e.target.value);
    fetchBatches(e.target.value);
    fetchStudents(e.target.value, startDate);
  };

  const handleBatchChange = (e) => {
    setSelectedBatch(e.target.value);
    fetchStudentsForBatch(e.target.value);
  };

  const handleStartDateChange = (e) => {
    setStartDate(e.target.value);
    if (selectedCourse) {
      fetchStudents(selectedCourse, e.target.value);
    }
  };

  const addStudentDropdown = () => {
    setSelectedStudents([...selectedStudents, { studentId: '' }]);
  };

  const handleStudentChange = (index, e) => {
    const newSelectedStudents = [...selectedStudents];
    newSelectedStudents[index].studentId = e.target.value;
    setSelectedStudents(newSelectedStudents);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const batch = {
      courseName: selectedCourse,
      scheduleDay,
      batchNumber,
      startDate,
      endDate,
      students: selectedStudents.map(s => ({ id: s.studentId }))
    };
    console.log('Batch data to be submitted:', batch);
    try {
      await axios.post('http://localhost:8080/api/batches', batch);
      alert('Batch created successfully!');
    } catch (error) {
      console.error('Error creating batch:', error);
    }
  };

  return (
    <div className="batch-container">
      <h1>Create Batch</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Course:
          <select value={selectedCourse} onChange={handleCourseChange}>
            <option value="">Select Course</option>
            {courses.map(course => (
              <option key={course.id} value={course.name}>{course.name}</option>
            ))}
          </select>
        </label>
        <label>
          Schedule Day:
          <select value={scheduleDay} onChange={e => setScheduleDay(e.target.value)}>
            <option value="">Select Schedule Day</option>
            <option value="MON_WED_FRI">MON_WED_FRI</option>
            <option value="TUE_THURS">TUE_THURS</option>
            <option value="SAT_SUN">SAT_SUN</option>
          </select>
        </label>
        <label>
          Batch Number:
          <input
            type="text"
            value={batchNumber}
            onChange={e => setBatchNumber(e.target.value)}
            required
          />
        </label>
        <label>
          Start Date:
          <input
            type="date"
            value={startDate}
            onChange={handleStartDateChange}
            required
          />
        </label>
        <label>
          End Date:
          <input
            type="date"
            value={endDate}
            onChange={e => setEndDate(e.target.value)}
            required
          />
        </label>
        <div className="students-dropdowns">
          {selectedStudents.map((s, index) => (
            <div key={index} className="student-dropdown">
              <label>
                Student:
                <select
                  name="studentId"
                  value={s.studentId}
                  onChange={(e) => handleStudentChange(index, e)}
                >
                  <option value="">Select Student</option>
                  {students.map(student => (
                   <option key={student.id} value={student.id}>{`${student.firstName} ${student.lastName}`}</option>
                  ))}
                </select>
              </label>
              {index === selectedStudents.length - 1 && (
                <button type="button" onClick={addStudentDropdown}>+</button>
              )}
            </div>
          ))}
        </div>
        <button type="submit">Submit</button>
      </form>

      <h2>View Batches</h2>
      <label>
        Course:
        <select value={selectedCourse} onChange={handleCourseChange}>
          <option value="">Select Course</option>
          {courses.map(course => (
            <option key={course.id} value={course.name}>{course.name}</option>
          ))}
        </select>
      </label>
      <label>
        Batch:
        <select value={selectedBatch} onChange={handleBatchChange}>
          <option value="">Select Batch</option>
          {batches.map(batch => (
            <option key={batch.id} value={batch.id}>{batch.batchNumber}</option>
          ))}
        </select>
      </label>
      {selectedBatch && (
        <div className="batch-details">
          <h3>Students in Batch {selectedBatch}</h3>
          <ul>
            {students.map(student => (
              <li key={student.id}>{`${student.firstName} ${student.lastName}`}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default Batch;
