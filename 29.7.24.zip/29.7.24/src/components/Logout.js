import { useEffect } from 'react';

const Logout = () => {
  useEffect(() => {
    // Clear the authentication token
    localStorage.removeItem('authToken');

    // Redirect to the login page
    window.location.href = '/login';
  }, []);

  return null; // No need to render anything
};

export default Logout;