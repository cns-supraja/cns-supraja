import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './StudentEnrollment.css';

const StudentEnrollment = () => {
  const [personalDetails, setPersonalDetails] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phoneNumber: '',
    contactedStatus: '',
    description: '',
  });

  const [courseDetails, setCourseDetails] = useState({
    courseType: '',
    courseName: '',
    days: '',
    training: false,
    trainingAndCertification: false,
    exam: false,
  });

  const [students, setStudents] = useState([]);
  const [cnsCourses, setCnsCourses] = useState([]);
  const [redhatCourses, setRedhatCourses] = useState([]);
  const [comboCourses, setComboCourses] = useState([]);
  const [courseSyllabus, setCourseSyllabus] = useState([]);
  const [editingStudent, setEditingStudent] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:8080/api/students')
      .then(response => setStudents(response.data))
      .catch(error => console.error('Error fetching students:', error));

    axios.get('http://localhost:8080/api/courses')
      .then(response => setCnsCourses(response.data))
      .catch(error => console.error('Error fetching CNS courses:', error));

    axios.get('http://localhost:8080/api/courses')
      .then(response => setRedhatCourses(response.data))
      .catch(error => console.error('Error fetching Redhat courses:', error));

    axios.get('http://localhost:8080/api/combo-courses')
      .then(response => setComboCourses(response.data))
      .catch(error => console.error('Error fetching combo courses:', error));

    axios.get('http://localhost:8080/api/course-syllabus')
      .then(response => setCourseSyllabus(response.data))
      .catch(error => console.error('Error fetching course syllabus:', error));
  }, []);

  const handlePersonalDetailsChange = (e) => {
    const { name, value } = e.target;
    setPersonalDetails(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleCourseDetailsChange = (e) => {
    const { name, value, type, checked } = e.target;
    setCourseDetails(prevState => ({
      ...prevState,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const student = { ...personalDetails, enrollment: { ...courseDetails } };

    if (editingStudent) {
      axios.put(`http://localhost:8080/api/students/${editingStudent.id}`, student)
        .then(response => {
          setStudents(students.map(s => (s.id === editingStudent.id ? response.data : s)));
          setEditingStudent(null);
        })
        .catch(error => console.error('Error updating student:', error));
    } else {
      axios.post('http://localhost:8080/api/students', student)
        .then(response => {
          setStudents([...students, response.data]);
        })
        .catch(error => console.error('Error creating student:', error));
    }

    setPersonalDetails({
      firstName: '',
      lastName: '',
      email: '',
      phoneNumber: '',
      contactedStatus: '',
      description: '',
    });
    setCourseDetails({
      courseType: '',
      courseName: '',
      days: '',
      training: false,
      trainingAndCertification: false,
      exam: false,
    });
  };

  const handleEdit = (student) => {
    setEditingStudent(student);
    setPersonalDetails({
      firstName: student.firstName,
      lastName: student.lastName,
      email: student.email,
      phoneNumber: student.phoneNumber,
      contactedStatus: student.contactedStatus,
      description: student.description,
    });
    setCourseDetails(student.enrollment);
  };

  const handleDelete = (id) => {
    axios.delete(`http://localhost:8080/api/students/${id}`)
      .then(() => {
        setStudents(students.filter(student => student.id !== id));
      })
      .catch(error => console.error('Error deleting student:', error));
  };

  const filteredCourses = () => {
    switch (courseDetails.courseType) {
      case 'CNS':
        return cnsCourses;
      case 'Redhat':
        return redhatCourses;
      case 'Internship':
        return courseSyllabus;
      case 'Combo':
        return comboCourses;
      default:
        return [];
    }
  };

  return (
    <div className="student-enrollment">
      <h1>Student Enrollment</h1>
      <form onSubmit={handleSubmit}>
        <fieldset>
          <legend>Personal Details</legend>
          <label>
            First Name:
            <input
              type="text"
              name="firstName"
              value={personalDetails.firstName}
              onChange={handlePersonalDetailsChange}
              required
            />
          </label>
          <label>
            Last Name:
            <input
              type="text"
              name="lastName"
              value={personalDetails.lastName}
              onChange={handlePersonalDetailsChange}
              required
            />
          </label>
          <label>
            Email:
            <input
              type="email"
              name="email"
              value={personalDetails.email}
              onChange={handlePersonalDetailsChange}
              required
            />
          </label>
          <label>
            Phone Number:
            <input
              type="tel"
              name="phoneNumber"
              value={personalDetails.phoneNumber}
              onChange={handlePersonalDetailsChange}
              required
            />
          </label>
          <label>
            Contacted Status:
            <input
              type="date"
              name="contactedStatus"
              value={personalDetails.contactedStatus}
              onChange={handlePersonalDetailsChange}
              required
            />
          </label>
          <label>
            Description:
            <textarea
              name="description"
              value={personalDetails.description}
              onChange={handlePersonalDetailsChange}
              required
            />
          </label>
        </fieldset>
        <fieldset>
          <legend>Course Details</legend>
          <label>
            Course Type:
            <select
              name="courseType"
              value={courseDetails.courseType}
              onChange={handleCourseDetailsChange}
            >
              <option value="">Select</option>
              <option value="CNS">CNS Course</option>
              <option value="Redhat">Redhat Course</option>
              <option value="Internship">Internship</option>
              <option value="Combo">Combo Course</option>
            </select>
          </label>
          {courseDetails.courseType && (
            <label>
              Course Name:
              <select
                name="courseName"
                value={courseDetails.courseName}
                onChange={handleCourseDetailsChange}
              >
                <option value="">Select</option>
                {filteredCourses().map(course => (
                  <option key={course.id} value={course.name}>{course.name}</option>
                ))}
              </select>
            </label>
          )}
          {courseDetails.courseType === 'Redhat' && (
            <fieldset>
              <legend>Requirements</legend>
              <label>
                Training
                <input
                  type="checkbox"
                  name="training"
                  checked={courseDetails.training}
                  onChange={handleCourseDetailsChange}
                />
              </label>
              <label>
                Training and Certification
                <input
                  type="checkbox"
                  name="trainingAndCertification"
                  checked={courseDetails.trainingAndCertification}
                  onChange={handleCourseDetailsChange}
                />
              </label>
              <label>
                Exam
                <input
                  type="checkbox"
                  name="exam"
                  checked={courseDetails.exam}
                  onChange={handleCourseDetailsChange}
                />
              </label>
            </fieldset>
          )}
          {courseDetails.courseType === 'Internship' && (
            <label>
              Days:
              <select
                name="days"
                value={courseDetails.days}
                onChange={handleCourseDetailsChange}
                required
              >
                <option value="">Select</option>
                <option value="15 days">15 days</option>
                <option value="1 month">1 month</option>
                <option value="3 months">3 months</option>
                <option value="4 months">4 months</option>
              </select>
            </label>
          )}
          {courseDetails.courseType === 'Combo' &&  (
            
            <fieldset>
              <label>
                    Course 1:
                    <select
                      name="courseName1"
                      value={courseDetails.courseName1}
                      onChange={handleCourseDetailsChange}
                    >
                      <option value="">Select</option>
                      {filteredCourses().map(course => (
                        <option key={course.id} value={course.name}>{course.name}</option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Course 2:
                    <select
                      name="courseName2"
                      value={courseDetails.courseName2}
                      onChange={handleCourseDetailsChange}
                    >
                      <option value="">Select</option>
                      {filteredCourses().map(course => (
                        <option key={course.id} value={course.name}>{course.name}</option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Course 3:
                    <select
                      name="courseName3"
                      value={courseDetails.courseName3}
                      onChange={handleCourseDetailsChange}
                    >
                      <option value="">Select</option>
                      {filteredCourses().map(course => (
                        <option key={course.id} value={course.name}>{course.name}</option>
                      ))}
                    </select>
                  </label>
              <legend>Requirements</legend>
              <label>
                Training
                <input
                  type="checkbox"
                  name="training"
                  checked={courseDetails.training}
                  onChange={handleCourseDetailsChange}
                />
              </label>
              <label>
                Training and Certification
                <input
                  type="checkbox"
                  name="trainingAndCertification"
                  checked={courseDetails.trainingAndCertification}
                  onChange={handleCourseDetailsChange}
                />
              </label>
              <label>
                Exam
                <input
                  type="checkbox"
                  name="exam"
                  checked={courseDetails.exam}
                  onChange={handleCourseDetailsChange}
                />
              </label>
            </fieldset>
          )}
        </fieldset>
        <button type="submit">{editingStudent ? 'Update' : 'Submit'}</button>
      </form>
      <h2>Student List</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>Contacted Status</th>
            <th>Description</th>
            <th>Course Type</th>
            <th>Course Name</th>
            <th>Days</th>
            <th>Training</th>
            <th>Training and Certification</th>
            <th>Exam</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students.map(student => (
            <tr key={student.id}>
              <td>{student.id}</td>
              <td>{student.firstName}</td>
              <td>{student.lastName}</td>
              <td>{student.email}</td>
              <td>{student.phoneNumber}</td>
              <td>{student.contactedStatus}</td>
              <td>{student.description}</td>
              <td>{student.enrollment.courseType}</td>
              <td>{student.enrollment.courseName}</td>
              <td>{student.enrollment.days}</td>
              <td>{student.enrollment.training ? 'Yes' : 'No'}</td>
              <td>{student.enrollment.trainingAndCertification ? 'Yes' : 'No'}</td>
              <td>{student.enrollment.exam ? 'Yes' : 'No'}</td>
              <td>
                <button onClick={() => handleEdit(student)}>Edit</button>
                <button onClick={() => handleDelete(student.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default StudentEnrollment;
