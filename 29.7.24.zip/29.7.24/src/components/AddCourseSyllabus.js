// src/components/AddCourseSyllabus.js
import React, { useState } from 'react';
import axios from 'axios';
import './AddCourseSyllabus.css'

function AddCourseSyllabus() {
  const [courseName, setCourseName] = useState('');
  const [syllabus, setSyllabus] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const data = { courseName, syllabus };

    axios.post('http://localhost:8080/api/course-syllabus', data)
      .then(response => {
        console.log(response.data);
        setCourseName('');
        setSyllabus('');
      })
      .catch(error => console.error(error));
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Course Name:</label>
        <input 
          type="text" 
          value={courseName} 
          onChange={(e) => setCourseName(e.target.value)} 
          required 
        />
      </div>
      <div>
        <label>Course Syllabus:</label>
        <textarea 
          value={syllabus} 
          onChange={(e) => setSyllabus(e.target.value)} 
          required 
        />
      </div>
      <button type="submit">Submit</button>
    </form>
  );
}

export default AddCourseSyllabus;
