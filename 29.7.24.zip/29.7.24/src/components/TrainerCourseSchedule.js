// src/components/TrainerCourseSchedule.jsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './TrainerCourseSchedule.css'; // Import your CSS for styling

const TrainerCourseSchedule = () => {
  const [schedules, setSchedules] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchSchedules();
  }, []);

  const fetchSchedules = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/course-schedules');
      console.log('Fetched schedules:', response.data); // Log fetched data
      setSchedules(Array.isArray(response.data) ? response.data : []);
    } catch (error) {
      console.error('Error fetching schedules:', error);
      setError('Failed to fetch schedules');
    }
  };

  const handleCheckboxChange = async (scheduleId, isFinished) => {
    try {
      await axios.patch(`http://localhost:8080/api/course-schedules/${scheduleId}`, { finished: isFinished });
      fetchSchedules(); // Refresh the schedule list
    } catch (error) {
      console.error('Error updating schedule status:', error);
      setError('Failed to update schedule status');
    }
  };

  return (
    <div className="trainer-course-schedule-container">
      <h1>Course Schedules</h1>
      {error && <p className="error-message">{error}</p>}
      <table className="schedule-table">
        <thead>
          <tr>
            <th>Course</th>
            <th>Trainer</th>
            <th>Type</th>
            <th>Mode</th>
            <th>Days</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Time</th>
            <th>Finished</th>
          </tr>
        </thead>
        <tbody>
          {schedules.map((schedule) => (
            <tr key={schedule.id}>
              <td>{schedule.courseName}</td>
              <td>{schedule.trainerName}</td>
              <td>{schedule.scheduleType}</td>
              <td>{schedule.mode}</td>
              <td>{schedule.scheduleDays}</td>
              <td>{new Date(schedule.startDate).toLocaleDateString()}</td>
              <td>{new Date(schedule.endDate).toLocaleDateString()}</td>
              <td>{schedule.time}</td>
              <td>
                <input
                  type="checkbox"
                  checked={schedule.finished || false}
                  onChange={(e) => handleCheckboxChange(schedule.id, e.target.checked)}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TrainerCourseSchedule;
