package com.student.cnslms.controller;

import com.student.cnslms.model.CourseSchedule;
import com.student.cnslms.repository.CourseScheduleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/course-schedules")
public class CourseScheduleController {
    @Autowired
    private CourseScheduleRepository courseScheduleRepository;

    @GetMapping
    public List<CourseSchedule> getAllCourseSchedules() {
        return courseScheduleRepository.findAll();
    }

    @PostMapping
    public ResponseEntity<CourseSchedule> createCourseSchedule(@RequestBody CourseSchedule courseSchedule) {
        if (courseSchedule.getCourseName() == null) {
            throw new IllegalArgumentException("Course name cannot be null");
        }
        CourseSchedule savedCourseSchedule = courseScheduleRepository.save(courseSchedule);
        return new ResponseEntity<>(savedCourseSchedule, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public CourseSchedule updateCourseSchedule(@PathVariable Long id, @RequestBody CourseSchedule courseScheduleDetails) {
        CourseSchedule courseSchedule = courseScheduleRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Course Schedule not found"));

        courseSchedule.setCourseName(courseScheduleDetails.getCourseName());
        courseSchedule.setTrainerName(courseScheduleDetails.getTrainerName());
        courseSchedule.setScheduleType(courseScheduleDetails.getScheduleType());
        courseSchedule.setMode(courseScheduleDetails.getMode());
        courseSchedule.setScheduleDays(courseScheduleDetails.getScheduleDays());
        courseSchedule.setStartDate(courseScheduleDetails.getStartDate());
        courseSchedule.setEndDate(courseScheduleDetails.getEndDate());
        courseSchedule.setTime(courseScheduleDetails.getTime());
        courseSchedule.setDuration(courseScheduleDetails.getDuration());

        return courseScheduleRepository.save(courseSchedule);
    }

    @DeleteMapping("/{id}")
    public void deleteCourseSchedule(@PathVariable Long id) {
        courseScheduleRepository.deleteById(id);
    }
}
