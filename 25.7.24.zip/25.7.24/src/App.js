// src/App.js
import React, { useState } from 'react';
import LoginPage from './components/LoginPage';
import HomePage from './components/HomePage'; // Import AdminHomePage
import StudentHomePage from './components/StudentHomePage'; // Import StudentHomePage

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userType, setUserType] = useState(null);

  const handleLogin = (loginStatus, type) => {
    setIsLoggedIn(loginStatus);
    setUserType(type);
  };

  return (
    <div className="App">
      {isLoggedIn ? (
        userType === 'admin' ? (
          <HomePage />
        ) : userType === 'student' ? (
          <StudentHomePage />
        ) : (
          <div>Unauthorized access</div>
        )
      ) : (
        <LoginPage onLogin={handleLogin} />
      )}
    </div>
  );
}

export default App;
