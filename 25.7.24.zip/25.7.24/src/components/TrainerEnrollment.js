import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './TrainerEnrollmentForm.css';

const TrainerEnrollmentForm = () => {
  const [form, setForm] = useState({
    id: '',
    firstName: '',
    lastName: '',
    email: '',
    phoneNumber: '',
  });
  const [trainers, setTrainers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchTrainers();
  }, []);

  const fetchTrainers = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/trainers');
      setTrainers(response.data);
    } catch (error) {
      console.error('Error fetching trainers', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (form.id) {
        await axios.put(`http://localhost:8080/api/trainers/${form.id}`, form);
      } else {
        await axios.post('http://localhost:8080/api/trainers', form);
      }
      fetchTrainers();
      setForm({
        id: '',
        firstName: '',
        lastName: '',
        email: '',
        phoneNumber: '',
      });
    } catch (error) {
      console.error('Error saving trainer', error);
      setError('Error saving trainer');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (trainer) => {
    setForm(trainer);
  };

  const handleDelete = async (id) => {
    setLoading(true);
    try {
      await axios.delete(`http://localhost:8080/api/trainers/${id}`);
      fetchTrainers();
    } catch (error) {
      console.error('Error deleting trainer', error);
      setError('Error deleting trainer');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <h1>Trainer Enrollment</h1>
      {error && <p className="error">{error}</p>}
      <form onSubmit={handleFormSubmit}>
        <input type="hidden" name="id" value={form.id} />

        <div className="row">
          <div className="form-group">
            <label>First Name:</label>
            <input
              type="text"
              name="firstName"
              value={form.firstName}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Last Name:</label>
            <input
              type="text"
              name="lastName"
              value={form.lastName}
              onChange={handleInputChange}
              required
            />
          </div>
        </div>

        <div className="row">
          <div className="form-group">
            <label>Email:</label>
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleInputChange}
              required
              pattern="^\S+@\S+$"
              title="Invalid email format"
            />
          </div>

          <div className="form-group">
            <label>Phone Number:</label>
            <input
              type="text"
              name="phoneNumber"
              value={form.phoneNumber}
              onChange={handleInputChange}
              required
              pattern="^[0-9]+$"
              title="Phone number must be numeric"
            />
          </div>
        </div>

        <button type="submit" disabled={loading}>
          {loading ? 'Submitting...' : 'Submit'}
        </button>
      </form>

      <h2>Enrolled Trainers</h2>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Phone Number</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {trainers.map((trainer) => (
              <tr key={trainer.id}>
                <td>{trainer.firstName}</td>
                <td>{trainer.lastName}</td>
                <td>{trainer.email}</td>
                <td>{trainer.phoneNumber}</td>
                <td className="actions">
                  <button onClick={() => handleEdit(trainer)}>Edit</button>
                  <button onClick={() => handleDelete(trainer.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default TrainerEnrollmentForm;
