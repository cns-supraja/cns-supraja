import React, { useState } from 'react';
import StudentEnrollment from './StudentEnrollment';
import TrainerEnrollment from './TrainerEnrollment';
import Course from './Course';
import CourseSchedule from './CourseSchedule';
//import AssessmentForm from './AssessmentForm';
//import AssessmentPage from './AssessmentPage';
//import GuidedExercisePage from './GuidedExercisePage';
//import Attendance from './Attendance';
//import BatchPage from './BatchPage';
import Logout from './Logout';
//import ViewStudents from './ViewStudents'
import './HomePage.css';


const HomePage = () => {
  const [view, setView] = useState('home');

  return (
    <div className="home-page">
      <div className="navbar">
        
        <ul>
         <li onClick={() => setView('home')}>Home</li>
          <li onClick={() => setView('Course')}>Course</li>
          <li onClick={() => setView('StudentEnrollment')}>Student Enrollment</li>
          <li onClick={() => setView('TrainerEnrollment')}>Trainer Enrollment</li>
          <li onClick={() => setView('CourseSchedule')}>Course Schedule</li>
          <li onClick={() => setView('logout')}>Logout</li>
        
        </ul>
      </div>
      <div className="content">
        {view === 'home' && <div>Welcome to the LMS Home Page</div>}
        
        {view === 'Course' && <Course />}
        {view === 'StudentEnrollment' && <StudentEnrollment />}
        {view === 'TrainerEnrollment' && <TrainerEnrollment />}
        {view === 'CourseSchedule' && <CourseSchedule />}
        {view === 'Logout' && <Logout />}
       
        
      </div>
    </div>
  );
};

export default HomePage;

