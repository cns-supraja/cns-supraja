package com.student.cnslms.controller;

import com.student.cnslms.model.Batch;
import com.student.cnslms.model.Student;
import com.student.cnslms.service.BatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/batches")
public class BatchController {

    @Autowired
    private BatchService batchService;

    @PostMapping
    public Batch createBatch(@RequestBody Batch batch) {
        return batchService.createBatch(batch);
    }

    @GetMapping("/students")
    public List<Student> getStudentsByCourseAndDateRange(
            @RequestParam Long courseId,
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate) {
        return batchService.getStudentsByCourseAndDateRange(courseId, startDate, endDate);
    }

    @GetMapping
    public List<Batch> getBatchesByCourse(@RequestParam Long courseId) {
        return batchService.getBatchesByCourse(courseId);
    }

    @GetMapping("/{id}")
    public Optional<Batch> getBatchById(@PathVariable Long id) {
        return batchService.getBatchById(id);
    }
}

