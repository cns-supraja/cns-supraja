// src/main/java/com/student/cnslms/controller/CourseController.java
package com.student.cnslms.controller;

import com.student.cnslms.model.Course;
import com.student.cnslms.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CourseController {
    @Autowired
    private CourseService courseService;
    
    @PostMapping("/courses")
    public ResponseEntity<Course> addCourse(@RequestBody Course course) {
        Course savedCourse = courseService.saveCourse(course);
        return ResponseEntity.ok(savedCourse);
    }

    @GetMapping("/courses")
    public ResponseEntity<List<Course>> getAllCourses() {
        List<Course> courses = courseService.getAllCourses();
        return ResponseEntity.ok(courses);
    }

    @GetMapping("/cns-courses")
    public ResponseEntity<List<Course>> getCnsCourses() {
        List<Course> courses = courseService.getCoursesByType("CNS");
        return ResponseEntity.ok(courses);
    }

    @GetMapping("/redhat-courses")
    public ResponseEntity<List<Course>> getRedhatCourses() {
        List<Course> courses = courseService.getCoursesByType("Redhat");
        return ResponseEntity.ok(courses);
    }

    @GetMapping("/combo-courses")
    public ResponseEntity<List<Course>> getComboCourses() {
        List<Course> courses = courseService.getCoursesByType("Combo");
        return ResponseEntity.ok(courses);
    }

    @GetMapping("/course-syllabus")
    public ResponseEntity<List<Course>> getCourseSyllabus() {
    	List<Course> coursesWithSyllabus = courseService.getCoursesWithSyllabus();
        return ResponseEntity.ok(coursesWithSyllabus);
    }
}