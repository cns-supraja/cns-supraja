package com.student.cnslms.model;

public enum ScheduleDays {
	
	  MON_WED_FRI, TUE_THURS, SAT_SUN

}
