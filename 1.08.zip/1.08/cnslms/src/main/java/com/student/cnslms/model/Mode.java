package com.student.cnslms.model;

public enum Mode {
	ONLINE,
    OFFLINE
}
