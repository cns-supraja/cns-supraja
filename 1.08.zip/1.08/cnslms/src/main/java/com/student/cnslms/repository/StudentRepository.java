package com.student.cnslms.repository;


import com.student.cnslms.model.Student;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface StudentRepository extends JpaRepository<Student, Long> {
	
	Student findByEmail(String email);
	
	 List<Student> findByBatchId(Long batchId);
	 List<Student> findStudentsByBatchId(Long batchId);
	 List<Student> findByCourseIdAndEnrollmentDateBetween(Long courseId, LocalDate startDate, LocalDate endDate);
	  @Query("SELECT s FROM Student s WHERE s.course.id = :courseId AND s.enrollmentDate BETWEEN :startDate AND :endDate")
	    List<Student> findEnrolledStudents(Long courseId, LocalDate startDate, LocalDate endDate);

	  @Query("SELECT s FROM Student s WHERE s.course.id = :courseId AND s.enrollmentDate BETWEEN :startDate AND :endDate")
	    List<Student> findStudentsByCourseAndDateRange(@Param("courseId") Long courseId, @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
}
