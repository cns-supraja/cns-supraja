package com.student.cnslms.service;

import com.student.cnslms.model.Student;
import com.student.cnslms.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class StudentService {
    @Autowired
    private StudentRepository studentRepository;

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }
    public List<Student> getStudentsByBatch(Long batchId) {
        return studentRepository.findStudentsByBatchId(batchId);
    }
    public Optional<Student> getStudentById(Long id) {
        return studentRepository.findById(id);
    }

    public Student saveStudent(Student student) {
        return studentRepository.save(student);
    }

    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
    }
    
    public List<Student> findEnrolledStudentsByCourseAndDate(Long courseId, LocalDate startDate, LocalDate endDate) {
        // Implement the method to find students based on courseId and date range
        return studentRepository.findByCourseIdAndEnrollmentDateBetween(courseId, startDate, endDate);
    }
    
    public List<Student> getEnrolledStudents(Long courseId, LocalDate startDate, LocalDate endDate) {
        // Fetch students based on courseId, startDate, and endDate
        return studentRepository.findEnrolledStudents(courseId, startDate, endDate);
    }
    
}
