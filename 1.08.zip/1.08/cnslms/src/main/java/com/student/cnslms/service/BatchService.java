package com.student.cnslms.service;

import com.student.cnslms.model.Batch;
import com.student.cnslms.model.Student;
import com.student.cnslms.repository.BatchRepository;
import com.student.cnslms.repository.StudentRepository;
import com.student.cnslms.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class BatchService {

    @Autowired
    private BatchRepository batchRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private CourseRepository courseRepository;

    public Batch createBatch(Batch batch) {
        return batchRepository.save(batch);
    }

    public List<Student> getStudentsByCourseAndDateRange(Long courseId, LocalDate startDate, LocalDate endDate) {
        return studentRepository.findStudentsByCourseAndDateRange(courseId, startDate, endDate);
    }

    public List<Batch> getBatchesByCourse(Long courseId) {
        // Implement if you need specific queries for batches by course
        return batchRepository.findAll(); // Example placeholder
    }

    public Optional<Batch> getBatchById(Long id) {
        return batchRepository.findById(id);
    }
}
