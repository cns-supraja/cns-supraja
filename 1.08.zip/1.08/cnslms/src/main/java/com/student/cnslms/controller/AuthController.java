package com.student.cnslms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.student.Stuenroll.controller.AuthController.LoginRequest;
import com.student.cnslms.model.Student;
import com.student.cnslms.model.Trainer;
import com.student.cnslms.repository.StudentRepository;
import com.student.cnslms.repository.TrainerRepository;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "password";

    @Autowired
    private StudentRepository studentRepository;
    @Autowired
    private TrainerRepository trainerRepository;

    // Admin login endpoint
    @CrossOrigin(origins = "http://localhost:3000")
    @PostMapping("/login")
    public String login(@RequestBody LoginRequest loginRequest) {
        if (ADMIN_USERNAME.equals(loginRequest.getUsername()) && ADMIN_PASSWORD.equals(loginRequest.getPassword())) {
            return "Login successful";
        } else {
            return "Login failed";
        }
    }

    // Student login endpoint
    @CrossOrigin(origins = "http://localhost:3000")
    @PostMapping("/student/login")
    public ResponseEntity<String> studentLogin(@RequestBody StudentLoginRequest studentLoginRequest) {
        Student student = studentRepository.findByEmail(studentLoginRequest.getEmail());
        if (student != null && student.getPhoneNumber().equals(studentLoginRequest.getPhoneNumber())) {
            return ResponseEntity.ok("Student login successful");
        } else {
            return ResponseEntity.status(401).body("Invalid credentials");
        }
    }

 // Class to represent the admin login request
    public static class LoginRequest {
        private String username;
        private String password;

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }
    }

    // Class to represent the student login request
    public static class StudentLoginRequest {
        private String email;
        private String phoneNumber;

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }
    }
    
    @CrossOrigin(origins = "http://localhost:3000")
    @PostMapping("/trainer/login")
    public ResponseEntity<String> trainerLogin(@RequestBody TrainerLoginRequest trainerLoginRequest) {
        Trainer trainer = trainerRepository.findByEmail(trainerLoginRequest.getEmail());
        if (trainer != null && trainer.getPhoneNumber().equals(trainerLoginRequest.getPhoneNumber())) {
            return ResponseEntity.ok("Trainer login successful");
        } else {
            return ResponseEntity.status(401).body("Invalid credentials");
        }
    }

    // Class to represent the trainer login request
    public static class TrainerLoginRequest {
        private String email;
        private String phoneNumber;

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }
    }
}

