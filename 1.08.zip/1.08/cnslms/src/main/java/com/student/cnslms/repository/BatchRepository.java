package com.student.cnslms.repository;

import com.student.cnslms.model.Batch;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BatchRepository extends JpaRepository<Batch, Long> {
    // Custom queries can be added here if needed
}
