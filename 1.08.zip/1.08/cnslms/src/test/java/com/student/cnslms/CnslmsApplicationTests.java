package com.student.cnslms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CnslmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
