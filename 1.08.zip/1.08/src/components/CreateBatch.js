import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';

const CreateBatch = () => {
  const [courses, setCourses] = useState([]);
  const [studentOptions, setStudentOptions] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState('');
  const [scheduleDays, setScheduleDays] = useState('MON_WED_FRI');
  const [batchNumber, setBatchNumber] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [students, setStudents] = useState([]);

  // Fetch all courses on component mount
  useEffect(() => {
    axios.get('http://localhost:8080/api/courses')
      .then(response => setCourses(response.data))
      .catch(error => console.error('Error fetching courses:', error));
  }, []);

  // Fetch students when the selected course or date range changes
  const handleFetchStudents = useCallback(async () => {
    if (selectedCourse && startDate && endDate) {
      try {
        const response = await axios.get('http://localhost:8080/api/students', {
          params: {
            courseId: selectedCourse,
            startDate,
            endDate,
          },
        });
        setStudentOptions(response.data);
      } catch (error) {
        console.error('Error fetching students:', error);
      }
    }
  }, [selectedCourse, startDate, endDate]);

  useEffect(() => {
    handleFetchStudents();
  }, [handleFetchStudents]);

  // Add a new empty student select field
  const handleAddStudent = () => {
    setStudents(prevStudents => [...prevStudents, '']);
  };

  // Remove a student select field by index
  const handleRemoveStudent = index => {
    setStudents(prevStudents => prevStudents.filter((_, i) => i !== index));
  };

  // Handle form submission
  const handleSubmit = (event) => {
    event.preventDefault();
    
    if (!selectedCourse || !batchNumber || !startDate || !endDate) {
      alert('Please fill in all required fields.');
      return;
    }
  
    const batchData = {
      courseId: selectedCourse,
      scheduleDays,
      batchNumber,
      startDate,
      endDate,
      students: students
        .filter(id => id) // Remove any empty student IDs
        .map(id => ({ id })) // Format as an array of objects
    };
  
    axios.post('http://localhost:8080/api/batches', batchData)
      .then(response => {
        console.log('Batch created:', response.data);
        // Clear form on success
        setSelectedCourse('');
        setScheduleDays('MON_WED_FRI');
        setBatchNumber('');
        setStartDate('');
        setEndDate('');
        setStudents([]);
      })
      .catch(error => console.error('Error creating batch:', error));
  };

  return (
    <div>
      <h2>Create Batch</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Course:</label>
          <select value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)}>
            <option value="">Select a course</option>
            {courses.map(course => (
              <option key={course.id} value={course.id}>{course.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label>Schedule Days:</label>
          <select value={scheduleDays} onChange={(e) => setScheduleDays(e.target.value)}>
            <option value="MON_WED_FRI">MON_WED_FRI</option>
            <option value="TUE_THURS">TUE_THURS</option>
            <option value="SAT_SUN">SAT_SUN</option>
          </select>
        </div>
        <div>
          <label>Batch Number:</label>
          <input type="text" value={batchNumber} onChange={(e) => setBatchNumber(e.target.value)} />
        </div>
        <div>
          <label>Start Date:</label>
          <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
        </div>
        <div>
          <label>End Date:</label>
          <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
        </div>
        <div>
          <label>Students:</label>
          {students.map((student, index) => (
            <div key={index}>
              <select value={student} onChange={(e) => {
                const newStudents = [...students];
                newStudents[index] = e.target.value;
                setStudents(newStudents);
              }}>
                <option value="">Select a student</option>
                {studentOptions.map(opt => (
                  <option key={opt.id} value={opt.id}>{`${opt.firstName} ${opt.lastName}`}</option>
                ))}
              </select>
              <button type="button" onClick={() => handleRemoveStudent(index)}>X</button>
            </div>
          ))}
          <button type="button" onClick={handleAddStudent}>+</button>
        </div>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default CreateBatch;
