import React from 'react';
import './StudentHomePage.css'; // Import the CSS file for styling

const StudentHomePage = () => {
  return (
    <div className="student-homepage">
      <nav className="sidebar">
        <h2>Student Dashboard</h2>
        <ul>
          <li><a href="#profile">Profile</a></li>
          <li><a href="#courses">Courses</a></li>
          <li><a href="#grades">Grades</a></li>
          <li><a href="#logout">Logout</a></li>
        </ul>
      </nav>
      <div className="content">
        <h1>Welcome to CubenSquare</h1>
      </div>
    </div>
  );
};

export default StudentHomePage;