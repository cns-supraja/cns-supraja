import React from 'react';
import CreateBatch from './CreateBatch';
import ViewBatches from './ViewBatches';

const App = () => {
  return (
    <div>
      <CreateBatch />
      <ViewBatches />
    </div>
  );
};

export default App;