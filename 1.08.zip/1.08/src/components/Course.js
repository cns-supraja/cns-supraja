import React, { useState } from 'react';
import axios from 'axios';

const CourseUpload = () => {
  const [course, setCourse] = useState({
    name: '',
    type: '',
    syllabus: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCourse({
      ...course,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    axios.post('http://localhost:8080/api/courses', course)
      .then((response) => {
        alert('Course uploaded successfully!');
        setCourse({
          name: '',
          type: '',
          syllabus: '',
        });
      })
      .catch((error) => {
        console.error('Error uploading course:', error);
      });
  };

  return (
    <div>
      <h1>Upload Course</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Course Name:</label>
          <input
            type="text"
            name="name"
            value={course.name}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Course Type:</label>
          <select
            name="type"
            value={course.type}
            onChange={handleChange}
          >
            <option value="">Select</option>
            <option value="CNS">CNS</option>
            <option value="Redhat">Redhat</option>
            <option value="Internship">Internship</option>
          </select>
        </div>
        <div>
          <label>Syllabus:</label>
          <textarea
            name="syllabus"
            value={course.syllabus}
            onChange={handleChange}
          />
        </div>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default CourseUpload;