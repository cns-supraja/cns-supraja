// src/components/AddComboCourse.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './AddComboCourse.css';

function AddComboCourse() {
  const [syllabuses, setSyllabuses] = useState([]);
  const [courses, setCourses] = useState([{ syllabusId: '', type: 'CNS', requirements: [] }]);

  useEffect(() => {
    axios.get('http://localhost:8080/api/course-syllabus')
      .then(response => setSyllabuses(response.data))
      .catch(error => console.error(error));
  }, []);

  const handleAddCourse = () => {
    setCourses([...courses, { syllabusId: '', type: 'CNS', requirements: [] }]);
  };

  const handleCourseChange = (index, key, value) => {
    const updatedCourses = [...courses];
    updatedCourses[index][key] = value;
    setCourses(updatedCourses);
  };

  const handleRequirementChange = (index, requirement) => {
    const updatedCourses = [...courses];
    const courseRequirements = updatedCourses[index].requirements;
    if (courseRequirements.includes(requirement)) {
      updatedCourses[index].requirements = courseRequirements.filter(req => req !== requirement);
    } else {
      updatedCourses[index].requirements = [...courseRequirements, requirement];
    }
    setCourses(updatedCourses);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:8080/api/combo-course', { courses })
      .then(response => {
        console.log(response.data);
        setCourses([{ syllabusId: '', type: 'CNS', requirements: [] }]);
      })
      .catch(error => console.error(error));
  };

  return (
    <form onSubmit={handleSubmit}>
      {courses.map((course, index) => (
        <div key={index}>
          <div>
            <label>Course Syllabus:</label>
            <select 
              value={course.syllabusId} 
              onChange={(e) => handleCourseChange(index, 'syllabusId', e.target.value)} 
              required
            >
              <option value="" disabled>Select a syllabus</option>
              {syllabuses.map(syllabus => (
                <option key={syllabus.id} value={syllabus.id}>
                  {syllabus.courseName}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label>Type:</label>
            <select 
              value={course.type} 
              onChange={(e) => handleCourseChange(index, 'type', e.target.value)} 
              required
            >
              <option value="CNS">CNS courses</option>
              <option value="Redhat">Redhat Course</option>
              <option value="Internship">Internship</option>
            </select>
          </div>
          <div>
            <label>Requirements:</label>
            <div>
              <label>
                <input 
                  type="checkbox" 
                  checked={course.requirements.includes('training')} 
                  onChange={() => handleRequirementChange(index, 'training')} 
                /> Training
              </label>
              <label>
                <input 
                  type="checkbox" 
                  checked={course.requirements.includes('certification')} 
                  onChange={() => handleRequirementChange(index, 'certification')} 
                /> Training and Certification
              </label>
              <label>
                <input 
                  type="checkbox" 
                  checked={course.requirements.includes('exam')} 
                  onChange={() => handleRequirementChange(index, 'exam')} 
                /> Exam
              </label>
            </div>
          </div>
        </div>
      ))}
      <button type="button" onClick={handleAddCourse}>Add Course</button>
      <button type="submit">Submit</button>
    </form>
  );
}

export default AddComboCourse;
