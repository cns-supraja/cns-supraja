import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ViewBatches = () => {
  const [courses, setCourses] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState('');
  const [batches, setBatches] = useState([]);
  const [selectedBatch, setSelectedBatch] = useState(null);
  const [students, setStudents] = useState([]);
  const [error, setError] = useState(null);

  // Fetch courses on component mount
  useEffect(() => {
    axios.get('http://localhost:8080/api/courses')
      .then(response => setCourses(response.data))
      .catch(error => setError('Error fetching courses'));
  }, []);

  // Fetch batches when a course is selected
  useEffect(() => {
    if (selectedCourse) {
      axios.get(`http://localhost:8080/api/batches?courseId=${selectedCourse}`)
        .then(response => setBatches(response.data))
        .catch(error => setError('Error fetching batches'));
    } else {
      setBatches([]);
    }
  }, [selectedCourse]);

  // Fetch students when a batch is selected
  useEffect(() => {
    if (selectedBatch) {
      axios.get(`http://localhost:8080/api/batches/${selectedBatch.id}/students`)
        .then(response => setStudents(response.data))
        .catch(error => setError('Error fetching students'));
    } else {
      setStudents([]);
    }
  }, [selectedBatch]);

  // Handle batch selection
  const handleBatchSelect = (batchId) => {
    const batch = batches.find(b => b.id === batchId);
    setSelectedBatch(batch);
  };

  return (
    <div>
      <h2>View Batches</h2>
      {error && <p>{error}</p>}
      <div>
        <label>Course:</label>
        <select value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)}>
          <option value="">Select a course</option>
          {courses.map(course => (
            <option key={course.id} value={course.id}>{course.name}</option>
          ))}
        </select>
      </div>
      <div>
        <label>Batch:</label>
        <select value={selectedBatch ? selectedBatch.id : ''} onChange={(e) => handleBatchSelect(e.target.value)}>
          <option value="">Select a batch</option>
          {batches.map(batch => (
            <option key={batch.id} value={batch.id}>{batch.batchNumber}</option>
          ))}
        </select>
      </div>
      {selectedBatch && (
        <div>
          <h3>Batch Details</h3>
          <p>Batch Number: {selectedBatch.batchNumber}</p>
          <p>Schedule Days: {selectedBatch.scheduleDays}</p>
          <p>Date Range: {selectedBatch.startDate} to {selectedBatch.endDate}</p>
          <p>Number of Students: {students.length}</p>
          <h4>Students</h4>
          <ul>
            {students.map(student => (
              <li key={student.id}>{student.firstName} {student.lastName}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default ViewBatches;
