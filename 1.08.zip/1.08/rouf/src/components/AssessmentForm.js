import React, { useState } from 'react';
import './AssessmentForm.css';

const AssessmentForm = () => {
    const [assessmentNumber, setAssessmentNumber] = useState('');
    const [topic, setTopic] = useState('');
    const [questions, setQuestions] = useState([]);

    const handleAddQuestion = () => {
        setQuestions([...questions, { questionNumber: '', questionText: '', choices: [''], correctAnswer: '' }]);
    };

    const handleQuestionChange = (index, field, value) => {
        const newQuestions = [...questions];
        newQuestions[index][field] = value;
        setQuestions(newQuestions);
    };

    const handleAddChoice = (index) => {
        const newQuestions = [...questions];
        newQuestions[index].choices.push('');
        setQuestions(newQuestions);
    };

    const handleChoiceChange = (questionIndex, choiceIndex, value) => {
        const newQuestions = [...questions];
        newQuestions[questionIndex].choices[choiceIndex] = value;
        setQuestions(newQuestions);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const assessment = { assessmentNumber, topic, questions };

        const response = await fetch('http://localhost:8080/api/assessments', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(assessment),
        });

        if (response.ok) {
            alert('Assessment created successfully!');
        } else {
            alert('Failed to create assessment.');
        }
    };

    return (
        <div className="assessment-form">
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Assessment No:</label>
                    <input
                        type="text"
                        value={assessmentNumber}
                        onChange={(e) => setAssessmentNumber(e.target.value)}
                        required
                    />
                    <label>Topic:</label>
                    <input
                        type="text"
                        value={topic}
                        onChange={(e) => setTopic(e.target.value)}
                        required
                    />
                </div>

                {questions.map((question, index) => (
                    <div key={index} className="question-group">
                        <label>Qno:</label>
                        <input
                            type="text"
                            value={question.questionNumber}
                            onChange={(e) => handleQuestionChange(index, 'questionNumber', e.target.value)}
                            required
                        />
                        <label>Question:</label>
                        <input
                            type="text"
                            value={question.questionText}
                            onChange={(e) => handleQuestionChange(index, 'questionText', e.target.value)}
                            required
                        />
                        {question.choices.map((choice, choiceIndex) => (
                            <div key={choiceIndex} className="choice-group">
                                <label>{String.fromCharCode(65 + choiceIndex)}.</label>
                                <input
                                    type="text"
                                    value={choice}
                                    onChange={(e) => handleChoiceChange(index, choiceIndex, e.target.value)}
                                    required
                                />
                            </div>
                        ))}
                        <button type="button" onClick={() => handleAddChoice(index)}>Add choice</button>
                        <label>Answer:</label>
                        <input
                            type="text"
                            value={question.correctAnswer}
                            onChange={(e) => handleQuestionChange(index, 'correctAnswer', e.target.value)}
                            required
                        />
                    </div>
                ))}
                <button type="button" onClick={handleAddQuestion}>Add Question</button>
                <button type="submit">Submit Assessment</button>
            </form>
        </div>
    );
};

export default AssessmentForm;
