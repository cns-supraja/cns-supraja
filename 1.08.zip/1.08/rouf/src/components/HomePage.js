import React, { useState } from 'react';
import StudentEnrollmentForm from './StudentEnrollmentForm';

import TrainerEnrollmentForm from './TrainerEnrollmentForm';

import CourseForm from './CourseForm';
import CourseSchedule from './CourseSchedule';
import AssessmentForm from './AssessmentForm';
import AssessmentPage from './AssessmentPage';
import GuidedExercisePage from './GuidedExercisePage';
import Attendance from './Attendance';
import BatchPage from './BatchPage';
import Logout from './Logout';
import ViewStudents from './ViewStudents'
import './HomePage.css';


const HomePage = () => {
  const [view, setView] = useState('home');

  return (
    <div className="home-page">
      <div className="navbar">
        
        <ul>
          <li onClick={() => setView('home')}>Home</li>
          <li onClick={() => setView('enrollStudent')}>Student Enrollment</li>
          <li onClick={() => setView('viewStudents')}>View Students</li>
          <li onClick={() => setView('enrollTrainer')}>Trainer Enrollment</li>
        
          <li onClick={() => setView('course')}>Course</li>
          <li onClick={() => setView('courseSchedule')}>Schedule course</li>
          <li onClick={() => setView('assessmentForm')}>Assessment Form</li>
          <li onClick={() => setView('viewAssessment')}>View Assessments</li>
          <li onClick={() => setView('guidedExercise')}>Guided Exercise</li>
          <li onClick={() => setView('attendance')}>Attendance</li>
          <li onClick={() => setView('batch')}>Batch</li>
          <li onClick={() => setView('logout')}>Logout</li>
        
        </ul>
      </div>
      <div className="content">
        {view === 'home' && <div>Welcome to the LMS Home Page</div>}
        {view === 'enrollStudent' && <StudentEnrollmentForm />}
        {view === 'viewStudents' && <ViewStudents />}
        {view === 'enrollTrainer' && <TrainerEnrollmentForm />}
        
        {view === 'course' && <CourseForm />}
        {view === 'courseSchedule'&& <CourseSchedule />}
        {view === 'assessmentForm' && <AssessmentForm />}
        {view === 'viewAssessment' && <AssessmentPage />}
        {view === 'guidedExercise' && <GuidedExercisePage />}
        {view === 'attendance' && <Attendance />}
        {view === 'batch' && <BatchPage />}
        {view === 'logout' && <Logout />}
        
      </div>
    </div>
  );
};

export default HomePage;

