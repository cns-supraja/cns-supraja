import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './ViewStudents.css';

const ViewStudents = () => {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    setLoading(true);
    try {
      const response = await axios.get('http://localhost:8080/api/students');
      setStudents(response.data);
    } catch (error) {
      setError('Error fetching students');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    setLoading(true);
    try {
      await axios.delete(`http://localhost:8080/api/students/${id}`);
      // Update students list after deletion
      setStudents(students.filter(student => student.id !== id));
    } catch (error) {
      setError('Error deleting student');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (student) => {
    // Placeholder for edit functionality, e.g., navigate to edit form or open modal
    console.log('Editing student:', student);
  };

  return (
    <div className="container">
      <h1>View Students</h1>
      {error && <p className="error">{error}</p>}
      <table>
        <thead>
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>Course</th>
            <th>Payment Status</th>
            <th>Contacted Status</th>
            <th>Description</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students.map((student) => (
            <tr key={student.id}>
              <td>{student.firstName}</td>
              <td>{student.lastName}</td>
              <td>{student.email}</td>
              <td>{student.phoneNumber}</td>
              <td>{student.course?.name}</td>
              <td>{student.paymentStatus}</td>
              <td>{student.contactedStatus}</td>
              <td>{student.description}</td>
              <td>
                <button onClick={() => handleEdit(student)}>Edit</button>
                <button onClick={() => handleDelete(student.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ViewStudents;
