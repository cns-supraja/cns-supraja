import React, { useEffect, useState } from 'react';

const ViewTrainers = () => {
  const [trainers, setTrainers] = useState([]);
  const [editingTrainer, setEditingTrainer] = useState(null);

  useEffect(() => {
    fetch('http://localhost:8080/api/trainers')
      .then(response => response.json())
      .then(data => setTrainers(data))
      .catch(error => console.error('Error fetching trainers:', error));
  }, []);

  const handleEditClick = (trainer) => {
    setEditingTrainer(trainer);
  };

  const handleChange = (e) => {
    setEditingTrainer({ ...editingTrainer, [e.target.name]: e.target.value });
  };

  const handleSave = async () => {
    try {
      const response = await fetch(`http://localhost:8080/api/trainers/${editingTrainer.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(editingTrainer),
      });

      if (response.ok) {
        alert('Trainer updated successfully');
        setEditingTrainer(null);
        setTrainers(trainers.map(t => (t.id === editingTrainer.id ? editingTrainer : t)));
      } else {
        alert('Error updating trainer');
      }
    } catch (err) {
      alert('Error connecting to the server');
    }
  };

  return (
    <div className="view-trainers-container">
      <h2>View Trainers</h2>
      {editingTrainer ? (
        <div className="edit-form">
          <h3>Edit Trainer</h3>
          <form>
            <div>
              <label>First Name:</label>
              <input type="text" name="firstName" value={editingTrainer.firstName} onChange={handleChange} />
            </div>
            <div>
              <label>Last Name:</label>
              <input type="text" name="lastName" value={editingTrainer.lastName} onChange={handleChange} />
            </div>
            <div>
              <label>Email:</label>
              <input type="email" name="email" value={editingTrainer.email} onChange={handleChange} />
            </div>
            <div>
              <label>Phone Number:</label>
              <input type="text" name="phoneNumber" value={editingTrainer.phoneNumber} onChange={handleChange} />
            </div>
            <div>
              <label>Course:</label>
              <select name="course" value={editingTrainer.course} onChange={handleChange}>
                <option value="DEVOPS">Devops</option>
                <option value="ANSIBLE">Ansible</option>
                <option value="FULLSTACK">Fullstack</option>
                <option value="OPENSHIFT">Openshift</option>
                <option value="KUBERNETES">Kubernetes</option>
              </select>
            </div>
            <button type="button" onClick={handleSave}>Save</button>
            <button type="button" onClick={() => setEditingTrainer(null)}>Cancel</button>
          </form>
        </div>
      ) : (
        <table>
          <thead>
            <tr>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Phone Number</th>
              <th>Course</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {trainers.map(trainer => (
              <tr key={trainer.id}>
                <td>{trainer.firstName}</td>
                <td>{trainer.lastName}</td>
                <td>{trainer.email}</td>
                <td>{trainer.phoneNumber}</td>
                <td>{trainer.course}</td>
                <td>
                  <button onClick={() => handleEditClick(trainer)}>Edit</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default ViewTrainers;
