import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './GuidedExercisePage.css';

const GuidedExercisePage = () => {
  const [courses, setCourses] = useState([]);
  const [students, setStudents] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState('');
  const [selectedStudents, setSelectedStudents] = useState([{ id: '', key: Date.now() }]);
  const [chapters, setChapters] = useState(Array.from({ length: 50 }, (_, i) => i + 1));
  const [selectedChapter, setSelectedChapter] = useState('');
  const [topics, setTopics] = useState([]);
  const [currentTopic, setCurrentTopic] = useState('');
  const [exercises, setExercises] = useState([]);
  const [addExercise, setAddExercise] = useState(false);
  const [selectedStudentForFilter, setSelectedStudentForFilter] = useState('');

  useEffect(() => {
    const axiosInstance = axios.create({ baseURL: 'http://localhost:8080' });

    const fetchData = async () => {
      try {
        const coursesResponse = await axiosInstance.get('/api/courses');
        setCourses(coursesResponse.data || []); // Ensure courses is an array
        const studentsResponse = await axiosInstance.get('/api/students');
        setStudents(studentsResponse.data || []); // Ensure students is an array
      } catch (error) {
        console.error('There was an error fetching the data!', error);
      }
    };

    fetchData();

    const fetchExercises = async () => {
      try {
        const response = await axiosInstance.get('/api/guided-exercises');
        setExercises(response.data || []); // Ensure exercises is an array
      } catch (error) {
        console.error('There was an error fetching the exercises!', error);
      }
    };

    fetchExercises();
    const intervalId = setInterval(fetchExercises, 10000);

    return () => clearInterval(intervalId);
  }, []);

  const handleAddStudent = (key) => {
    if (selectedStudents.some(student => student.id === '')) {
      alert('Please select a student before adding another.');
      return;
    }
    setSelectedStudents([...selectedStudents, { id: '', key: Date.now() }]);
  };

  const handleStudentChange = (key, value) => {
    setSelectedStudents(selectedStudents.map(student =>
      student.key === key ? { ...student, id: value } : student
    ));
  };

  const handleAddTopic = async () => {
    if (currentTopic) {
      try {
        const response = await axios.post('http://localhost:8080/api/topics', {
          chapter: selectedChapter,
          topic: currentTopic,
        });
        setTopics([...topics, response.data]);
        setCurrentTopic('');
      } catch (error) {
        console.error('There was an error adding the topic!', error);
      }
    }
  };

  const handleSubmit = () => {
    if (!selectedCourse) {
      alert('Please select a course.');
      return;
    }
    if (!selectedStudents.every(student => student.id)) {
      alert('Please select a student for all fields.');
      return;
    }
    if (!selectedChapter) {
      alert('Please select a chapter.');
      return;
    }
    if (!topics.length) {
      alert('Please add at least one topic.');
      return;
    }

    const newExercise = {
      courseId: selectedCourse,
      studentIds: selectedStudents.map(student => student.id),
      chapter: selectedChapter,
      topics: topics.map(topic => topic.id),
      progress: selectedStudents.map(() => 'open'), // Initialize progress for each student
    };

    axios.post('http://localhost:8080/api/guided-exercises', newExercise)
      .then(response => {
        setExercises([...exercises, response.data]);
        setAddExercise(false);
        setSelectedCourse('');
        setSelectedStudents([{ id: '', key: Date.now() }]);
        setSelectedChapter('');
        setTopics([]);
      })
      .catch(error => {
        console.error('There was an error creating the guided exercise!', error);
      });
  };

  const updateProgress = (exerciseIndex, studentIndex, value) => {
    const updatedExercises = [...exercises];
    updatedExercises[exerciseIndex].progress[studentIndex] = value;
    setExercises(updatedExercises);
  };

  const handleDeleteExercise = (exerciseId) => {
    axios.delete(`http://localhost:8080/api/guided-exercises/${exerciseId}`)
      .then(() => {
        setExercises(exercises.filter(exercise => exercise.id !== exerciseId));
      })
      .catch(error => {
        console.error('There was an error deleting the exercise!', error);
      });
  };

  return (
    <div className="guided-exercise-page">
      <h1>Guided Exercise</h1>

      <div className="form-group">
        <label>Course:</label>
        <select value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)}>
          <option value="">Select Course</option>
          {Array.isArray(courses) && courses.length > 0 && courses.map(course => (
            <option key={course.id} value={course.id}>{course.name}</option>
          ))}
        </select>
      </div>

      <div className="form-group">
        <label>Students:</label>
        {selectedStudents.map((student, index) => (
          <div key={student.key} style={{ display: 'flex', alignItems: 'center' }}>
            <select value={student.id} onChange={(e) => handleStudentChange(student.key, e.target.value)}>
              <option value="">Select Student</option>
              {Array.isArray(students) && students.length > 0 && students.map(st => (
                <option key={st.id} value={st.id}>{st.firstName} {st.lastName}</option>
              ))}
            </select>
            {index === selectedStudents.length - 1 && (
              <button onClick={() => handleAddStudent(student.key)}>+</button>
            )}
          </div>
        ))}
      </div>

      <button onClick={() => setSelectedStudents([{ id: '', key: Date.now() }])}>Clear Selected Students</button>

      <div className="form-group">
        <button onClick={() => setAddExercise(true)}>Add Exercise</button>
      </div>

      {addExercise && (
        <div className="add-exercise-form">
          <label>Chapter:</label>
          <select value={selectedChapter} onChange={(e) => setSelectedChapter(e.target.value)}>
            <option value="">Select Chapter</option>
            {chapters.map(chapter => (
              <option key={chapter} value={chapter}>{chapter}</option>
            ))}
          </select>
          <label>Topic:</label>
          <input type="text" value={currentTopic} onChange={(e) => setCurrentTopic(e.target.value)} />
          <button onClick={handleAddTopic}>Add Topic</button>
          <button onClick={handleSubmit}>Submit</button>
        </div>
      )}

      <div className="form-group">
        <label>Filter by Student:</label>
        <select value={selectedStudentForFilter} onChange={(e) => setSelectedStudentForFilter(e.target.value)}>
          <option value="">Select Student</option>
          {Array.isArray(students) && students.length > 0 && students.map(st => (
            <option key={st.id} value={st.id}>{st.firstName} {st.lastName}</option>
          ))}
        </select>
      </div>

      {Array.isArray(exercises) && exercises.length > 0 && (
        <div className="exercise-table">
          <h2>{selectedCourse && courses.find(c => c.id === selectedCourse)?.name} Guided Exercise</h2>
          <table>
            <thead>
              <tr>
                <th>Chapter</th>
                <th>Topics</th>
                <th>Actions</th>
                <th>Progress</th>
              </tr>
            </thead>
            <tbody>
              {exercises.map((exercise, index) => {
                const studentIndex = exercise.studentIds ? exercise.studentIds.indexOf(selectedStudentForFilter) : -1;
                return (
                  <tr key={exercise.id}>
                    <td>{exercise.chapter}</td>
                    <td>{exercise.topics && Array.isArray(exercise.topics) ? exercise.topics.join(', ') : ''}</td>
                    <td>
                      <button onClick={() => handleDeleteExercise(exercise.id)}>x</button>
                    </td>
                    <td>
                      {studentIndex !== -1 && exercise.progress && exercise.progress[studentIndex] !== undefined && (
                        <select value={exercise.progress[studentIndex]} onChange={(e) => updateProgress(index, studentIndex, e.target.value)}>
                          <option value="open">Open</option>
                          <option value="in-progress">In Progress</option>
                          <option value="completed">Completed</option>
                        </select>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default GuidedExercisePage;
