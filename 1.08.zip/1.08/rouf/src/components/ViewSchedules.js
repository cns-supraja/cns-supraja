import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ViewSchedules = () => {
  const [schedules, setSchedules] = useState([]);

  useEffect(() => {
    axios.get('/api/course-schedules')
      .then((response) => {
        setSchedules(response.data);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  return (
    <div>
      <h2>View Schedules</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Course</th>
            <th>Session Type</th>
            <th>Mode</th>
            <th>Type</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Time</th>
            <th>Duration (Months)</th>
            <th>Trainer</th>
          </tr>
        </thead>
        <tbody>
          {schedules.map((schedule) => (
            <tr key={schedule.id}>
              <td>{schedule.id}</td>
              <td>{schedule.course}</td>
              <td>{schedule.sessionType}</td>
              <td>{schedule.mode}</td>
              <td>{schedule.type}</td>
              <td>{schedule.startDate}</td>
              <td>{schedule.endDate}</td>
              <td>{schedule.time}</td>
              <td>{schedule.duration}</td>
              <td>{schedule.trainer ? schedule.trainer.name : 'N/A'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ViewSchedules;
