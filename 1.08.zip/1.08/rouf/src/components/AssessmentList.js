import React, { useEffect, useState } from 'react';
import './AssessmentList.css'

const AssessmentList = ({ onSelectAssessment }) => {
    const [assessments, setAssessments] = useState([]);

    useEffect(() => {
        const fetchAssessments = async () => {
            const response = await fetch('http://localhost:8080/api/assessments');
            const data = await response.json();
            setAssessments(data);
        };

        fetchAssessments();
    }, []);

    return (
        <div className="assessment-list">
            <h3>Assessments</h3>
            <ul>
                {assessments.map((assessment) => (
                    <li key={assessment.id} onClick={() => onSelectAssessment(assessment)}>
                        {assessment.assessmentNumber} - {assessment.topic}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default AssessmentList;
