import React from 'react';

const Navbar = ({ onNavClick }) => {
  return (
    <div className="navbar">
      <h3>Navigation</h3>
      <ul>
        <li onClick={() => onNavClick('home')}>Home</li>
        <li onClick={() => onNavClick('enrollment')}>Student Enrollment</li>
      </ul>
    </div>
  );
};

export default Navbar;
