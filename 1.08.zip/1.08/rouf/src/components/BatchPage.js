import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';
import './BatchPage.css';

const BatchPage = () => {
  const [courses, setCourses] = useState([]);
  const [scheduleDays, setScheduleDays] = useState([]);
  const [students, setStudents] = useState([]);
  const [batches, setBatches] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState('');
  const [selectedScheduleDay, setSelectedScheduleDay] = useState('');
  const [selectedBatchNumber, setSelectedBatchNumber] = useState('');
  const [selectedStudents, setSelectedStudents] = useState([{ id: '', key: uuidv4() }]);
  const [filterCourse, setFilterCourse] = useState('');
  const [filterBatch, setFilterBatch] = useState('');
  const [batchDetails, setBatchDetails] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [viewBatch, setViewBatch] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const coursesResponse = await axios.get('http://localhost:8080/api/courses');
        setCourses(coursesResponse.data);

        const studentsResponse = await axios.get('http://localhost:8080/api/students');
        setStudents(studentsResponse.data);

        const batchesResponse = await axios.get('http://localhost:8080/api/batches/summary');
        setBatches(batchesResponse.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  useEffect(() => {
    const fetchScheduleDays = async () => {
      try {
        const response = await axios.get('http://localhost:8080/api/batches/scheduleDays');
        setScheduleDays(response.data);
      } catch (error) {
        console.error('Error fetching schedule days:', error);
      }
    };
    fetchScheduleDays();
  }, []);

  const handleAddStudent = () => {
    if (selectedStudents.some(student => student.id === '')) {
      alert('Please select a student before adding another.');
      return;
    }
    setSelectedStudents([...selectedStudents, { id: '', key: uuidv4() }]);
  };

  const handleStudentChange = (key, value) => {
    setSelectedStudents(selectedStudents.map(student => student.key === key ? { ...student, id: value } : student));
  };

  const handleSubmit = async () => {
    if (!selectedCourse || !selectedScheduleDay || !selectedBatchNumber || !selectedStudents.every(student => student.id)) {
      alert('Please fill in all fields.');
      return;
    }

    const newBatch = {
      course: { id: selectedCourse },
      scheduleDay: selectedScheduleDay,
      batchNumber: selectedBatchNumber,
      students: selectedStudents.map(student => ({ id: student.id }))
    };

    try {
      const response = await axios.post('http://localhost:8080/api/batches', newBatch);
      setBatches([...batches, response.data]);
      setSelectedCourse('');
      setSelectedScheduleDay('');
      setSelectedBatchNumber('');
      setSelectedStudents([{ id: '', key: uuidv4() }]);
    } catch (error) {
      console.error('Error creating batch:', error);
    }
  };

  const handleFilterChange = async () => {
    if (!filterCourse || !filterBatch) {
      alert('Please select both course and batch number.');
      return;
    }

    try {
      const response = await axios.get(`http://localhost:8080/api/batches/course/${filterCourse}`);
      const selectedBatch = response.data.find(batch => batch.batchNumber === parseInt(filterBatch));
      setBatchDetails(selectedBatch ? selectedBatch.students : []);
    } catch (error) {
      console.error('Error fetching batch details:', error);
    }
  };

  const handleDeleteBatch = async (batchId) => {
    try {
      await axios.delete(`http://localhost:8080/api/batches/${batchId}`);
      setBatches(batches.filter(batch => batch.id !== batchId));
      alert('Batch deleted successfully');
    } catch (error) {
      console.error('Error deleting batch:', error);
    }
  };

  const handleAddStudentToBatch = async (batchId, studentId) => {
    try {
      await axios.post(`http://localhost:8080/api/batches/${batchId}/students`, { id: studentId });
      const updatedBatches = batches.map(batch => {
        if (batch.id === batchId) {
          return { ...batch, students: [...batch.students, { id: studentId }] };
        }
        return batch;
      });
      setBatches(updatedBatches);
      alert('Student added to batch successfully');
    } catch (error) {
      console.error('Error adding student to batch:', error);
    }
  };

  const handleViewBatch = (batch) => {
    setViewBatch(batch);
  };

  const handleDeleteStudentFromBatch = async (batchId, studentId) => {
    try {
      await axios.delete(`http://localhost:8080/api/batches/${batchId}/students/${studentId}`);
      const updatedBatches = batches.map(batch => {
        if (batch.id === batchId) {
          return { ...batch, students: batch.students.filter(student => student.id !== studentId) };
        }
        return batch;
      });
      setBatches(updatedBatches);
      if (viewBatch && viewBatch.id === batchId) {
        setViewBatch(updatedBatches.find(batch => batch.id === batchId));
      }
      alert('Student removed from batch successfully');
    } catch (error) {
      console.error('Error removing student from batch:', error);
    }
  };

  return (
    <div className="batch-page">
      <h1>Batch Management</h1>
      <div className="form-row">
        <div className="form-group">
          <label>Course:</label>
          <select value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)}>
            <option value="">Select Course</option>
            {isLoading ? (
              <option disabled>Loading...</option>
            ) : (
              courses.map(course => (
                <option key={course.id} value={course.id}>{course.name}</option>
              ))
            )}
          </select>
        </div>
        <div className="form-group">
          <label>Schedule Day:</label>
          <select value={selectedScheduleDay} onChange={(e) => setSelectedScheduleDay(e.target.value)}>
            <option value="">Select Schedule Day</option>
            {scheduleDays.map((day, index) => (
              <option key={index} value={day}>{day}</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label>Batch Number:</label>
          <select value={selectedBatchNumber} onChange={(e) => setSelectedBatchNumber(e.target.value)}>
            <option value="">Select Batch</option>
            {Array.from({ length: 100 }, (_, i) => i + 1).map(number => (
              <option key={number} value={number}>{number}</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label>Students:</label>
          {selectedStudents.map((student, index) => (
            <div key={student.key} className="student-select-group">
              <select value={student.id} onChange={(e) => handleStudentChange(student.key, e.target.value)}>
                <option value="">Select Student</option>
                {students
                  .filter(student => student.course && student.course.id === parseInt(selectedCourse))
                  .map(student => (
                    <option key={student.id} value={student.id}>{`${student.firstName} ${student.lastName}`}</option>
                  ))}
              </select>
              {index === selectedStudents.length - 1 && (
                <button type="button" onClick={handleAddStudent}>+</button>
              )}
            </div>
          ))}
        </div>
      </div>
      <button type="button" onClick={handleSubmit}>Submit</button>

      <h2>Batch Details</h2>
      <div className="filter-row">
        <div className="form-group">
          <label>Filter by Course:</label>
          <select value={filterCourse} onChange={(e) => setFilterCourse(e.target.value)}>
            <option value="">Select Course</option>
            {courses.map(course => (
              <option key={course.id} value={course.id}>{course.name}</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label>Filter by Batch:</label>
          <select value={filterBatch} onChange={(e) => setFilterBatch(e.target.value)}>
            <option value="">Select Batch</option>
            {Array.from({ length: 100 }, (_, i) => i + 1).map(number => (
              <option key={number} value={number}>{number}</option>
            ))}
          </select>
        </div>
        <button type="button" onClick={handleFilterChange}>Filter</button>
      </div>

      {batchDetails.length > 0 && (
        <div>
          <h3>Batch Members</h3>
          <table>
            <thead>
              <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {batchDetails.map(student => (
                <tr key={student.id}>
                  <td>{student.firstName}</td>
                  <td>{student.lastName}</td>
                  <td>
                    <button onClick={() => handleDeleteStudentFromBatch(filterBatch, student.id)}>Remove</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <h2>All Batches</h2>
      {isLoading ? (
        <p>Loading...</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Course</th>
              <th>Schedule Day</th>
              <th>Batch Number</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {batches.map(batch => (
              <tr key={batch.id}>
                <td>{batch.course.name}</td>
                <td>{batch.scheduleDay}</td>
                <td>{batch.batchNumber}</td>
                <td>
                  <button onClick={() => handleViewBatch(batch)}>View</button>
                  <button onClick={() => handleDeleteBatch(batch.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {viewBatch && (
        <div>
          <h3>Batch Details for {viewBatch.course.name} - Batch {viewBatch.batchNumber}</h3>
          <table>
            <thead>
              <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {viewBatch.students.map(student => (
                <tr key={student.id}>
                  <td>{student.firstName}</td>
                  <td>{student.lastName}</td>
                  <td>
                    <button onClick={() => handleDeleteStudentFromBatch(viewBatch.id, student.id)}>Remove</button>
                  </td>
                </tr>
              ))}
              <tr>
                <td colSpan="3">
                  <select onChange={(e) => handleAddStudentToBatch(viewBatch.id, e.target.value)}>
                    <option value="">Select Student to Add</option>
                    {students
                      .filter(student => student.course && student.course.id === parseInt(viewBatch.course.id))
                      .map(student => (
                        <option key={student.id} value={student.id}>{`${student.firstName} ${student.lastName}`}</option>
                      ))}
                  </select>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default BatchPage;
