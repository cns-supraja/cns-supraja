import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useForm } from 'react-hook-form';
import './StudentEnrollment.css';

const StudentEnrollment = () => {
  const [students, setStudents] = useState([]);
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { register, handleSubmit, reset, formState: { errors } } = useForm();

  useEffect(() => {
    fetchStudents();
    fetchCourses();
  }, []);

  const fetchStudents = async () => {
    setLoading(true);
    try {
      const response = await axios.get('http://localhost:8080/api/students');
      setStudents(response.data);
    } catch (error) {
      setError('Error fetching students');
    } finally {
      setLoading(false);
    }
  };

  const fetchCourses = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/courses');
      setCourses(response.data);
    } catch (error) {
      setError('Error fetching courses');
    }
  };

  const handleFormSubmit = async (data) => {
    setLoading(true);
    try {
      if (data.id) {
        await axios.put(`http://localhost:8080/api/students/${data.id}`, data);
      } else {
        await axios.post('http://localhost:8080/api/students', data);
      }
      fetchStudents();
      reset(); // Clear the form after successful submission
    } catch (error) {
      setError('Error saving student');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (student) => {
    reset(student);
  };

  const handleDelete = async (id) => {
    setLoading(true);
    try {
      await axios.delete(`http://localhost:8080/api/students/${id}`);
      fetchStudents();
    } catch (error) {
      setError('Error deleting student');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="student-enrollment-container">
      <h1>Student Enrollment</h1>
      {error && <p className="error">{error}</p>}
      <form onSubmit={handleSubmit(handleFormSubmit)}>
        <input type="hidden" {...register('id')} />
        <div className="form-row">
          <div className="form-group">
            <label>First Name:</label>
            <input type="text" {...register('firstName', { required: 'First name is required' })} />
            {errors.firstName && <p className="error">{errors.firstName.message}</p>}
          </div>
          <div className="form-group">
            <label>Last Name:</label>
            <input type="text" {...register('lastName', { required: 'Last name is required' })} />
            {errors.lastName && <p className="error">{errors.lastName.message}</p>}
          </div>
        </div>
        <div className="form-row">
          <div className="form-group">
            <label>Email:</label>
            <input type="email" {...register('email', { required: 'Email is required', pattern: { value: /^\S+@\S+$/i, message: 'Invalid email format' } })} />
            {errors.email && <p className="error">{errors.email.message}</p>}
          </div>
          <div className="form-group">
            <label>Phone Number:</label>
            <input type="text" {...register('phoneNumber', { required: 'Phone number is required', pattern: { value: /^[0-9]+$/, message: 'Phone number must be numeric' } })} />
            {errors.phoneNumber && <p className="error">{errors.phoneNumber.message}</p>}
          </div>
        </div>
        <div className="form-group">
          <label>Course:</label>
          <select {...register('course.id', { required: 'Course is required' })}>
            <option value="" disabled>Select a course</option>
            {courses.map((course) => (
              <option key={course.id} value={course.id}>
                {course.name}
              </option>
            ))}
          </select>
          {errors.course && <p className="error">{errors.course.message}</p>}
        </div>
        <div className="form-row">
          <div className="form-group">
            <label>Payment Status:</label>
            <select {...register('paymentStatus', { required: 'Payment status is required' })}>
              <option value="PAID">PAID</option>
              <option value="UNPAID">UNPAID</option>
              <option value="PENDING">PENDING</option>
            </select>
            {errors.paymentStatus && <p className="error">{errors.paymentStatus.message}</p>}
          </div>
          <div className="form-group">
            <label>Contacted Status:</label>
            <select {...register('contactedStatus', { required: 'Contacted status is required' })}>
              <option value="CONTACTED">CONTACTED</option>
              <option value="NOT_CONTACTED">NOT_CONTACTED</option>
              <option value="PENDING">PENDING</option>
            </select>
            {errors.contactedStatus && <p className="error">{errors.contactedStatus.message}</p>}
          </div>
        </div>
        <div className="form-group">
          <label>Description:</label>
          <textarea {...register('description')} />
        </div>
        <button type="submit" disabled={loading}>
          {loading ? 'Submitting...' : 'Submit'}
        </button>
      </form>
      <h2>Enrolled Students</h2>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Phone Number</th>
              <th>Course</th>
              <th>Payment Status</th>
              <th>Contacted Status</th>
              <th>Description</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {students.map((student) => (
              <tr key={student.id}>
                <td>{student.firstName}</td>
                <td>{student.lastName}</td>
                <td>{student.email}</td>
                <td>{student.phoneNumber}</td>
                <td>{student.course?.name}</td>
                <td>{student.paymentStatus}</td>
                <td>{student.contactedStatus}</td>
                <td>{student.description}</td>
                <td className="actions">
                  <button onClick={() => handleEdit(student)}>Edit</button>
                  <button onClick={() => handleDelete(student.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default StudentEnrollment;
