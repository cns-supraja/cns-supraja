import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Attendance = () => {
    const [courses, setCourses] = useState([]);
    const [selectedCourse, setSelectedCourse] = useState('');
    const [batches, setBatches] = useState([]);
    const [selectedBatch, setSelectedBatch] = useState('');
    const [students, setStudents] = useState([]);
    const [attendanceData, setAttendanceData] = useState([]);
    const [date, setDate] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    useEffect(() => {
        fetchCourses();
    }, []);

    const fetchCourses = async () => {
        try {
            const response = await axios.get('http://localhost:8080/api/attendance/courses');
            setCourses(response.data);
        } catch (error) {
            console.error('Error fetching courses:', error);
            setError('Error fetching courses. Please try again later.');
        }
    };

    const handleCourseChange = async (e) => {
        const courseId = e.target.value;
        setSelectedCourse(courseId);
        setSelectedBatch('');
        setStudents([]);
        setAttendanceData([]);
        setDate('');
        setError('');
        setLoading(true);
        try {
            const response = await axios.get(`http://localhost:8080/api/attendance/course/${courseId}/batches`);
            setBatches(response.data);
        } catch (error) {
            console.error('Error fetching batches:', error);
            setError('Error fetching batches. Please try again later.');
        } finally {
            setLoading(false);
        }
    };

    const handleBatchChange = async (e) => {
        const batchId = e.target.value;
        setSelectedBatch(batchId);
        setStudents([]);
        setAttendanceData([]);
        setDate('');
        setError('');
        setLoading(true);
        try {
            const response = await axios.get(`http://localhost:8080/api/attendance/batch/${batchId}/students`);
            setStudents(response.data);
        } catch (error) {
            console.error('Error fetching students:', error);
            setError('Error fetching students. Please try again later.');
        } finally {
            setLoading(false);
        }
    };

    const handleDateChange = (e) => {
        setDate(e.target.value);
    };

    const handleCastAttendance = async () => {
        if (!selectedBatch || !date) {
            setError('Please select a batch and a date.');
            return;
        }
        setLoading(true);
        setError('');
        try {
            const response = await axios.get(`http://localhost:8080/api/attendance/batch/${selectedBatch}/date/${date}`);
            setAttendanceData(response.data);
        } catch (error) {
            console.error('Error fetching attendance data:', error);
            setError('Error fetching attendance data. Please try again later.');
        } finally {
            setLoading(false);
        }
    };

    const handleAttendanceChange = (studentId, present) => {
        const updatedAttendance = attendanceData.map(att => {
            if (att.student.id === studentId) {
                return { ...att, present };
            }
            return att;
        });
        setAttendanceData(updatedAttendance);
    };

    const handleSubmitAttendance = async () => {
        setLoading(true);
        setError('');
        try {
            const formattedAttendance = attendanceData.map(att => ({
                id: att.id,
                student: { id: att.student.id },
                batch: { id: att.batch.id },
                date: date,
                present: att.present,
            }));
            await axios.post('http://localhost:8080/api/attendance', formattedAttendance);
            alert('Attendance saved successfully!');
        } catch (error) {
            console.error('Error saving attendance:', error);
            setError('Error saving attendance. Please try again later.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div>
            <h1>Attendance</h1>
            {error && <p>{error}</p>}
            <div>
                <label>Course:</label>
                <select value={selectedCourse} onChange={handleCourseChange}>
                    <option value="">Select a course</option>
                    {courses.map(course => (
                        <option key={course.id} value={course.id}>{course.name}</option>
                    ))}
                </select>
            </div>
            <div>
                <label>Date:</label>
                <input type="date" value={date} onChange={handleDateChange} />
            </div>
            <div>
                <label>Batch:</label>
                <select value={selectedBatch} onChange={handleBatchChange}>
                    <option value="">Select a batch</option>
                    {batches.map(batch => (
                        <option key={batch.id} value={batch.id}>{batch.batchNumber}</option>
                    ))}
                </select>
                {selectedBatch && date && (
                    <button onClick={handleCastAttendance} disabled={loading}>Cast Attendance</button>
                )}
            </div>
            {attendanceData.length > 0 && (
                <div>
                    <h2>Attendance Table</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Student Name</th>
                                <th>Attendance</th>
                            </tr>
                        </thead>
                        <tbody>
                            {attendanceData.map(att => (
                                <tr key={att.student.id}>
                                    <td>{att.student.name}</td>
                                    <td>
                                        <label>
                                            <input
                                                type="radio"
                                                name={`attendance-${att.student.id}`}
                                                value="present"
                                                checked={att.present}
                                                onChange={() => handleAttendanceChange(att.student.id, true)}
                                                disabled={loading}
                                            />
                                            Present
                                        </label>
                                        <label>
                                            <input
                                                type="radio"
                                                name={`attendance-${att.student.id}`}
                                                value="absent"
                                                checked={!att.present}
                                                onChange={() => handleAttendanceChange(att.student.id, false)}
                                                disabled={loading}
                                            />
                                            Absent
                                        </label>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    <button onClick={handleSubmitAttendance} disabled={loading}>Submit Attendance</button>
                </div>
            )}
        </div>
    );
};

export default Attendance;
