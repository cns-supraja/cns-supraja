import React, { useState } from 'react';
import axios from 'axios';
import './CourseForm.css';

function AddCourseForm() {
    const [courseName, setCourseName] = useState('');
    const [syllabus, setSyllabus] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:8080/api/courses/create', { name: courseName, syllabus });
            alert('Course created successfully!');
            setCourseName('');
            setSyllabus('');
        } catch (error) {
            console.error('Error creating course:', error);
        }
    };

    return (
        <div className="container">
            <h1>Add Course</h1>
            <form onSubmit={handleSubmit}>
                <div>
                    <label htmlFor="courseName">Course Name:</label>
                    <input
                        type="text"
                        id="courseName"
                        value={courseName}
                        onChange={(e) => setCourseName(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label htmlFor="syllabus">Syllabus:</label>
                    <textarea
                        id="syllabus"
                        value={syllabus}
                        onChange={(e) => setSyllabus(e.target.value)}
                        rows="4"
                        cols="50"
                        required
                    />
                </div>
                <button type="submit">Create Course</button>
            </form>
        </div>
    );
}

export default AddCourseForm;
