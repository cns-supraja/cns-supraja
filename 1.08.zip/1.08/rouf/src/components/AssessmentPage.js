import React, { useState } from 'react';
import AssessmentList from './AssessmentList';
//import './AssessmentPage.css'

const AssessmentPage = () => {
    const [selectedAssessment, setSelectedAssessment] = useState(null);

    const handleSelectAssessment = (assessment) => {
        setSelectedAssessment(assessment);
    };

    return (
        <div className="assessment-page">
            <AssessmentList onSelectAssessment={handleSelectAssessment} />
            {selectedAssessment && (
                <div className="assessment-detail">
                    <h3>Assessment: {selectedAssessment.assessmentNumber} - {selectedAssessment.topic}</h3>
                    <form>
                        {selectedAssessment.questions.map((question, index) => (
                            <div key={index} className="question-group">
                                <label>{question.questionNumber}. {question.questionText}</label>
                                {question.choices.map((choice, choiceIndex) => (
                                    <div key={choiceIndex} className="choice-group">
                                        <label>
                                            <input type="radio" name={`question-${index}`} value={choice} />
                                            {choice}
                                        </label>
                                    </div>
                                ))}
                            </div>
                        ))}
                        <button type="submit">Submit</button>
                    </form>
                </div>
            )}
        </div>
    );
};

export default AssessmentPage;
