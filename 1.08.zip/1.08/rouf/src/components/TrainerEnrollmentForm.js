import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useForm } from 'react-hook-form';
import './TrainerEnrollmentForm.css';

const TrainerEnrollmentForm = () => {
  const { register, handleSubmit, reset, formState: { errors } } = useForm();
  const [trainers, setTrainers] = useState([]);
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchTrainers();
    fetchCourses();
  }, []);

  const fetchTrainers = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/trainers');
      setTrainers(response.data);
    } catch (error) {
      console.error('Error fetching trainers', error);
    }
  };

  const fetchCourses = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/courses');
      setCourses(response.data);
    } catch (error) {
      console.error('Error fetching courses', error);
    }
  };

  const handleFormSubmit = async (data) => {
    try {
        if (data.id) {
            await axios.put(`http://localhost:8080/api/trainers/${data.id}`, data);
        } else {
            await axios.post('http://localhost:8080/api/trainers', data);
        }
        fetchTrainers();
        reset(); // Reset form after successful submission
    } catch (error) {
        console.error('Error saving trainer', error);
        setError('Error saving trainer');
    }
  };

  const handleEdit = (trainer) => {
    reset(trainer); // Populate form with trainer data for editing
  };

  const handleDelete = async (id) => {
    setLoading(true);
    try {
      await axios.delete(`http://localhost:8080/api/trainers/${id}`);
      fetchTrainers();
    } catch (error) {
      console.error('Error deleting trainer', error);
      setError('Error deleting trainer');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <h1>Trainer Enrollment</h1>
      {error && <p className="error">{error}</p>}
      <form onSubmit={handleSubmit(handleFormSubmit)}>
        <input type="hidden" {...register('id')} />

        <div className="row">
          <div className="form-group">
            <label>First Name:</label>
            <input type="text" {...register('firstName', { required: 'First name is required' })} />
            {errors.firstName && <p className="error">{errors.firstName.message}</p>}
          </div>

          <div className="form-group">
            <label>Last Name:</label>
            <input type="text" {...register('lastName', { required: 'Last name is required' })} />
            {errors.lastName && <p className="error">{errors.lastName.message}</p>}
          </div>
        </div>
        
        <div className="row">
          <div className="form-group">
            <label>Email:</label>
            <input
              type="email"
              {...register('email', {
                required: 'Email is required',
                pattern: {
                  value: /^\S+@\S+$/i,
                  message: 'Invalid email format'
                }
              })}
            />
            {errors.email && <p className="error">{errors.email.message}</p>}
          </div>

          <div className="form-group">
            <label>Phone Number:</label>
            <input
              type="text"
              {...register('phoneNumber', {
                required: 'Phone number is required',
                pattern: {
                  value: /^[0-9]+$/,
                  message: 'Phone number must be numeric'
                }
              })}
            />
            {errors.phoneNumber && <p className="error">{errors.phoneNumber.message}</p>}
          </div>
        </div>

        

        <button type="submit" disabled={loading}>
          {loading ? 'Submitting...' : 'Submit'}
        </button>
      </form>

      <h2>Enrolled Trainers</h2>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Phone Number</th>
              
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {trainers.map((trainer) => (
              <tr key={trainer.id}>
                <td>{trainer.firstName}</td>
                <td>{trainer.lastName}</td>
                <td>{trainer.email}</td>
                <td>{trainer.phoneNumber}</td>
                
                <td className="actions">
                  <button onClick={() => handleEdit(trainer)}>Edit</button>
                  <button onClick={() => handleDelete(trainer.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default TrainerEnrollmentForm;
